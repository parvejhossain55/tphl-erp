<?php
require_once __DIR__ . '/../models/CentralStatement.php';

class CentralStatementController extends Controller
{
    protected $db;
    protected $statementModel;

    public function __construct($db)
    {
        $this->db = $db;
        $this->statementModel = new CentralStatement($this->db);
        if (session_status() === PHP_SESSION_NONE) session_start();
    }

    /**
     * Main index - Show central statement page
     */
    public function index()
    {
        // Check if this is a print request
        $isPrint = isset($_GET['print']) && $_GET['print'] == 'true';

        // If it's a print request, use the print method
        if ($isPrint) {
            $this->printStatement();
            return;
        }

        // Get filters from query params with proper defaults
        $periodType = $_GET['period_type'] ?? 'monthly';
        $year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
        $month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;
        $projectId = $_GET['project_id'] ?? null;
        $category = $_GET['category'] ?? 'all';

        // Convert empty string to null for projectId
        if ($projectId === '') {
            $projectId = null;
        }

        // Get statement data based on period type
        $statementData = null;
        $periodText = '';
        $statementStartDate = '';
        $statementEndDate = '';

        switch ($periodType) {
            case 'monthly':
                $statementData = $this->statementModel->getMonthlyStatement($year, $month, $projectId, $category);
                $periodText = date('F Y', strtotime("$year-" . sprintf('%02d', $month) . "-01"));
                $statementStartDate = "$year-" . sprintf('%02d', $month) . "-01";
                $statementEndDate = date('Y-m-t', strtotime($statementStartDate));
                break;

            case '6months':
                $statementData = $this->statementModel->getSixMonthStatement($year, $month, $projectId, $category);
                $periodText = 'Last 6 Months';
                $statementStartDate = date('Y-m-01', strtotime("-5 months", strtotime("$year-$month-01")));
                $statementEndDate = date('Y-m-t', strtotime("$year-$month-01"));
                break;

            case 'yearly':
                $statementData = $this->statementModel->getYearlyStatement($year, $projectId, $category);
                $periodText = "Year $year";
                $statementStartDate = "$year-01-01";
                $statementEndDate = "$year-12-31";
                break;

            case 'custom':
                if ($startDate && $endDate) {
                    $statementData = $this->statementModel->getCustomRangeStatement($startDate, $endDate, $projectId, $category);
                    $periodText = date('d M, Y', strtotime($startDate)) . ' to ' . date('d M, Y', strtotime($endDate));
                    $statementStartDate = $startDate;
                    $statementEndDate = $endDate;
                } else {
                    // Default to current month if dates not provided
                    $year = (int)date('Y');
                    $month = (int)date('m');
                    $statementData = $this->statementModel->getMonthlyStatement($year, $month, $projectId, $category);
                    $periodText = date('F Y');
                    $periodType = 'monthly';
                    $statementStartDate = date('Y-m-01');
                    $statementEndDate = date('Y-m-t');
                }
                break;

            default:
                $year = (int)date('Y');
                $month = (int)date('m');
                $statementData = $this->statementModel->getMonthlyStatement($year, $month, $projectId, $category);
                $periodText = date('F Y');
                $periodType = 'monthly';
                $statementStartDate = date('Y-m-01');
                $statementEndDate = date('Y-m-t');
        }

        // Get projects for dropdown
        $projects = $this->getProjects();

        // Extract summary stats from the statement data
        $overallStats = [
            'total_agreement' => $statementData['summary']['total_agreement_value'] ?? 0,
            'total_service_fee' => $statementData['summary']['total_service_fee'] ?? 0,
            'total_management_cashin' => $statementData['summary']['total_management_cashin'] ?? 0,
            'total_cashin' => $statementData['summary']['total_cashin'] ?? 0,
            'total_revenue' => $statementData['summary']['total_revenue'] ?? 0,
            'total_cash_out' => $statementData['summary']['total_cash_out'] ?? 0,
            'net_balance' => $statementData['summary']['net_balance'] ?? 0,
            'final_balance' => $statementData['summary']['final_balance'] ?? 0
        ];

        // For the current statement period, also calculate revenue
        $revenueData = null;
        if ($statementStartDate && $statementEndDate) {
            $revenueData = $this->statementModel->calculateRevenue($statementStartDate, $statementEndDate, $projectId);
        }

        // Prepare view data
        $viewData = [
            'current_route' => 'central-statement',
            'page_title' => 'Central Financial Statement',
            'period_type' => $periodType,
            'period_text' => $periodText,
            'year' => $year,
            'month' => sprintf('%02d', $month),
            'start_date' => $startDate,
            'end_date' => $endDate,
            'project_id' => $projectId,
            'category' => $category,
            'projects' => $projects,
            'statement_data' => $statementData,
            'overall_stats' => $overallStats,
            'revenue_data' => $revenueData,
        ];

        $this->view('accounts/central-statement', $viewData);
    }

    /**
     * Get projects list
     */
    private function getProjects()
    {
        $query = "SELECT id, name FROM projects WHERE deleted_at IS NULL ORDER BY name";
        $result = $this->db->query($query);
        $projects = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $projects[] = $row;
            }
        }
        return $projects;
    }

    /**
     * Print statement - separate method for print view
     */
public function printStatement()
{
    // Get period type from query params
    $periodType = $_GET['period_type'] ?? 'monthly';
    $year = $_GET['year'] ?? date('Y');
    $month = $_GET['month'] ?? date('m');
    $startDate = $_GET['start_date'] ?? null;
    $endDate = $_GET['end_date'] ?? null;
    $projectId = $_GET['project_id'] ?? null;
    $category = $_GET['category'] ?? 'all';

    // Get statement data based on period type
    $statementData = null;
    $periodText = '';
    $statementStartDate = '';
    $statementEndDate = '';

    switch ($periodType) {
        case 'monthly':
            $statementData = $this->statementModel->getMonthlyStatement($year, $month, $projectId, $category);
            $periodText = date('F Y', strtotime("$year-$month-01"));
            $statementStartDate = "$year-$month-01";
            $statementEndDate = date('Y-m-t', strtotime($statementStartDate));
            break;

        case '6months':
            $statementData = $this->statementModel->getSixMonthStatement($year, $month, $projectId, $category);
            $periodText = 'Last 6 Months';
            $statementStartDate = date('Y-m-01', strtotime("-5 months", strtotime("$year-$month-01")));
            $statementEndDate = date('Y-m-t', strtotime("$year-$month-01"));
            break;

        case 'yearly':
            $statementData = $this->statementModel->getYearlyStatement($year, $projectId, $category);
            $periodText = "Year $year";
            $statementStartDate = "$year-01-01";
            $statementEndDate = "$year-12-31";
            break;

        case 'custom':
            if ($startDate && $endDate) {
                $statementData = $this->statementModel->getCustomRangeStatement($startDate, $endDate, $projectId, $category);
                $periodText = date('d M, Y', strtotime($startDate)) . ' to ' . date('d M, Y', strtotime($endDate));
                $statementStartDate = $startDate;
                $statementEndDate = $endDate;
            } else {
                // Default to current month if dates not provided
                $statementData = $this->statementModel->getMonthlyStatement(date('Y'), date('m'), $projectId, $category);
                $periodText = date('F Y');
                $periodType = 'monthly';
                $statementStartDate = date('Y-m-01');
                $statementEndDate = date('Y-m-t');
            }
            break;

        default:
            $statementData = $this->statementModel->getMonthlyStatement(date('Y'), date('m'), $projectId, $category);
            $periodText = date('F Y');
            $periodType = 'monthly';
            $statementStartDate = date('Y-m-01');
            $statementEndDate = date('Y-m-t');
    }

    // FIXED: Use consistent variable naming
    $statement_data = $statementData;
    
    // FIXED: Extract summary stats from the statement data
    $overall_stats = [
        'total_agreement' => $statement_data['summary']['total_agreement_value'] ?? 0,
        'total_service_fee' => $statement_data['summary']['total_service_fee'] ?? 0,
        'total_management_cashin' => $statement_data['summary']['total_management_cashin'] ?? 0,
        'total_cashin' => $statement_data['summary']['total_cashin'] ?? 0,
        'total_revenue' => $statement_data['summary']['total_revenue'] ?? 0,
        'total_cash_out' => $statement_data['summary']['total_cash_out'] ?? 0,
        'net_balance' => $statement_data['summary']['net_balance'] ?? 0,
        'final_balance' => $statement_data['summary']['final_balance'] ?? 0
    ];

    // Calculate revenue for the statement period
    $revenue_data = null;
    if ($statementStartDate && $statementEndDate) {
        $revenue_data = $this->statementModel->calculateRevenue($statementStartDate, $statementEndDate, $projectId);
    }

    // Company information
    $company_name = "THE PREMIUM HOMES LTD.";
    $company_address = "Land View Commercial Center, 9th Floor 28 Gulshan North C/A, Gulshan Circle-2, Dhaka";
    $company_phone = "+8801958253300";
    $company_email = "info@thepremiumhomes.com";

    // Get project name if filtered
    $projectName = '';
    if ($projectId) {
        $query = "SELECT name FROM projects WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $projectId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $projectName = $row['name'];
        }
    }

    // Get category name
    $categoryName = '';
    if ($category !== 'all') {
        $categoryName = ucfirst(str_replace('_', ' ', $category));
        // Special handling for cashout and utilities
        if ($category === 'cashout') {
            $categoryName = 'Cash Out';
        } elseif ($category === 'utilities') {
            $categoryName = 'Utilities (Bill/Electricity/Wifi/etc)';
        }
    }

    // FIXED: Pass all variables needed by the print view
    $viewData = [
        'statement_data' => $statement_data,
        'overall_stats' => $overall_stats,
        'period_text' => $periodText,
        'start_date' => $statementStartDate,
        'end_date' => $statementEndDate,
        'category' => $category,
        'projectName' => $projectName,
        'categoryName' => $categoryName,
        'company_name' => $company_name,
        'company_address' => $company_address,
        'company_phone' => $company_phone,
        'company_email' => $company_email,
        'period_type' => $periodType,
        'year' => $year,
        'month' => $month,
    ];

    // FIXED: If utilities category, get transactions
    if ($category === 'utilities') {
        $utilitiesTransactions = $this->statementModel->getUtilitiesTransactions($statementStartDate, $statementEndDate);
        $viewData['utilitiesTransactions'] = $utilitiesTransactions;
    }

    // FIXED: Include the print template with all variables
    extract($viewData);
    include __DIR__ . '/../views/accounts/central-statement-print.php';
    exit;
}

    /**
     * Export statement to CSV
     */
    public function exportCSV()
    {
        $periodType = $_GET['period_type'] ?? 'monthly';
        $year = $_GET['year'] ?? date('Y');
        $month = $_GET['month'] ?? date('m');
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;
        $projectId = $_GET['project_id'] ?? null;
        $category = $_GET['category'] ?? 'all';

        // Get statement data
        $statementData = null;
        $filename = 'central_statement_' . date('Ymd_His');

        switch ($periodType) {
            case 'monthly':
                $statementData = $this->statementModel->getMonthlyStatement($year, $month, $projectId, $category);
                $filename = "monthly_statement_{$year}_{$month}.csv";
                break;
            case '6months':
                $statementData = $this->statementModel->getSixMonthStatement($year, $month, $projectId, $category);
                $filename = "6months_statement_{$year}_{$month}.csv";
                break;
            case 'yearly':
                $statementData = $this->statementModel->getYearlyStatement($year, $projectId, $category);
                $filename = "yearly_statement_{$year}.csv";
                break;
            case 'custom':
                if ($startDate && $endDate) {
                    $statementData = $this->statementModel->getCustomRangeStatement($startDate, $endDate, $projectId, $category);
                    $cleanStartDate = str_replace('-', '', $startDate);
                    $cleanEndDate = str_replace('-', '', $endDate);
                    $filename = "custom_statement_{$cleanStartDate}_to_{$cleanEndDate}.csv";
                } else {
                    // Default to current month if dates not provided
                    $statementData = $this->statementModel->getMonthlyStatement(date('Y'), date('m'), $projectId, $category);
                    $filename = "monthly_statement_" . date('Y') . "_" . date('m') . ".csv";
                    $periodType = 'monthly';
                }
                break;
            default:
                $statementData = $this->statementModel->getMonthlyStatement(date('Y'), date('m'), $projectId, $category);
                $filename = "monthly_statement_" . date('Y') . "_" . date('m') . ".csv";
        }

        if (!$statementData) {
            setError('Unable to generate statement');
            header("Location: {$GLOBALS['base_url']}/central-statement");
            exit;
        }

        // Set CSV headers
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');

        // Write header
        fputcsv($output, ['Central Financial Statement']);
        fputcsv($output, ['Period: ' . $statementData['period']]);
        fputcsv($output, ['Start Date: ' . $statementData['start_date']]);
        fputcsv($output, ['End Date: ' . $statementData['end_date']]);
        fputcsv($output, ['Generated: ' . date('d M, Y h:i A')]);
        fputcsv($output, []); // Empty row

        // Write data based on type
        if (isset($statementData['daily_data'])) {
            // Daily breakdown - Update headers to match your new structure
            fputcsv($output, ['Date', 'Day', 'Agreement Value (৳)', 'Service Fee (৳)', 'Management Cashin (৳)', 'Total Cash IN (৳)', 'Cash Out (৳)', 'Net Amount (৳)', 'Running Balance (৳)']);
            foreach ($statementData['daily_data'] as $row) {
                fputcsv($output, [
                    $row['formatted_date'],
                    $row['day_name'],
                    number_format($row['agreement_value'] ?? 0, 2),
                    number_format($row['service_fee'] ?? 0, 2),
                    number_format($row['management_cashin'] ?? 0, 2),
                    number_format($row['total_cashin'] ?? 0, 2),
                    number_format($row['cash_out'] ?? 0, 2),
                    number_format($row['net_amount'] ?? 0, 2),
                    number_format($row['running_balance'] ?? 0, 2)
                ]);
            }
        } elseif (isset($statementData['monthly_data'])) {
            // Monthly breakdown - Update headers
            fputcsv($output, ['Month', 'Agreement Value (৳)', 'Service Fee (৳)', 'Management Cashin (৳)', 'Total Cash IN (৳)', 'Cash Out (৳)', 'Net Amount (৳)', 'Running Balance (৳)']);
            foreach ($statementData['monthly_data'] as $row) {
                fputcsv($output, [
                    $row['month'],
                    number_format($row['agreement_value'] ?? $row['landshare'] ?? 0, 2),
                    number_format($row['service_fee'] ?? 0, 2),
                    number_format($row['management_cashin'] ?? 0, 2),
                    number_format($row['total_cashin'] ?? $row['total_revenue'] ?? 0, 2),
                    number_format($row['cash_out'] ?? 0, 2),
                    number_format($row['net_amount'] ?? 0, 2),
                    number_format($row['running_balance'] ?? 0, 2)
                ]);
            }
        }

        // Write summary - Update to match new structure
        fputcsv($output, []); // Empty row
        fputcsv($output, ['SUMMARY']);
        fputcsv($output, ['Total Agreement Value', number_format($statementData['summary']['total_agreement'] ?? 0, 2)]);
        fputcsv($output, ['Total Service Fee', number_format($statementData['summary']['total_service_fee'] ?? 0, 2)]);
        fputcsv($output, ['Total Management Cashin', number_format($statementData['summary']['total_management_cashin'] ?? 0, 2)]);
        fputcsv($output, ['Total Cash IN', number_format($statementData['summary']['total_cashin'] ?? 0, 2)]);
        fputcsv($output, ['Total Cash Out', number_format($statementData['summary']['total_cash_out'] ?? 0, 2)]);
        fputcsv($output, ['Net Balance', number_format($statementData['summary']['net_balance'] ?? 0, 2)]);
        fputcsv($output, ['Final Balance', number_format($statementData['summary']['final_balance'] ?? 0, 2)]);

        fclose($output);
        exit;
    }

    /**
     * AJAX: Get quick stats
     */
    public function getQuickStats()
    {
        header('Content-Type: application/json');

        $stats = $this->statementModel->getOverallStatistics();

        echo json_encode([
            'success' => true,
            'data' => $stats
        ]);
        exit;
    }

    public function getRevenueStatistics()
    {
        header('Content-Type: application/json');

        $periodType = $_GET['period_type'] ?? 'monthly';
        $year = isset($_GET['year']) ? (int)$_GET['year'] : null;
        $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;
        $projectId = $_GET['project_id'] ?? null;

        $revenueStats = $this->statementModel->getRevenueStatistics(
            $periodType,
            $year,
            $month,
            $startDate,
            $endDate,
            $projectId
        );

        echo json_encode([
            'success' => true,
            'data' => $revenueStats
        ]);
        exit;
    }
}

<?php

class SalesHeadDashboardController extends Controller
{
    protected $db;
    protected $leadModel;
    protected $followUpModel;
    protected $projectModel;
    protected $bookingModel;
    protected $paymentModel;
    protected $userModel;
    protected $designationModel;
    protected $roleModel;
    public function __construct($db)
    {


        $this->db = $db;
        $this->leadModel = new Lead($this->db);
        $this->followUpModel = new FollowUp($this->db);
        $this->bookingModel = new BookingLead($this->db);
        $this->paymentModel = new PaymentLeadBooking($this->db);
        $this->projectModel = new Project($this->db);

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $this->designationModel = new Designation($this->db);
        $this->userModel = new User($this->db);
        $this->roleModel = new Role($this->db);
    }

    public function index()
    {
        //  Total Leads
        $totalLeads = $this->leadModel->getAll();
        $totalLeadsCount = count($totalLeads);

        //  New Leads Today
        $todayLeadsQuery = "SELECT COUNT(*) AS today_count FROM leads WHERE DATE(created_at) = CURDATE()";
        $todayLeadsResult = $this->db->query($todayLeadsQuery);
        $todayLeads = $todayLeadsResult->fetch_assoc()['today_count'] ?? 0;

        //  Follow-ups Due
        $followUpsQuery = "SELECT COUNT(*) AS due FROM lead_follow_ups WHERE follow_up_date <= CURDATE() AND status = 'pending' AND lead_follow_ups.deleted_at IS NULL";
        $followUpsResult = $this->db->query($followUpsQuery);
        $followUpsDue = $todayLeads;

        //  Onboarded Clients
        $onboardedQuery = "SELECT COUNT(*) AS onboarded FROM lead_bookings WHERE booking_status = 'booked' AND lead_bookings.deleted_at IS NULL";
        $onboardedResult = $this->db->query($onboardedQuery);
        $onboardedClients = $onboardedResult->fetch_assoc()['onboarded'] ?? 0;

        //  Booking Money Collected
        $bookingCollectedQuery = "SELECT SUM(amount) AS total_collected FROM lead_payments WHERE payment_type='booking_money' AND payment_status='paid'";
        $bookingCollectedResult = $this->db->query($bookingCollectedQuery);
        $bookingCollected = $bookingCollectedResult->fetch_assoc()['total_collected'] ?? 0;

        //  Conversion Rate
        $conversionRate = $totalLeadsCount > 0 ? ($onboardedClients / $totalLeadsCount) * 100 : 0;

        //  New Follow-ups Today (optional)
        $newFollowUpsQuery = "SELECT COUNT(*) AS new_followups FROM lead_follow_ups WHERE DATE(created_at) = CURDATE() AND lead_follow_ups.deleted_at IS NULL";
        $newFollowUpsResult = $this->db->query($newFollowUpsQuery);
        $newFollowUpsToday = $newFollowUpsResult->fetch_assoc()['new_followups'] ?? 0;

        $todayFollowUpCount = $this->followUpModel->getTodayFollowUpCountByLead();
        $totalTodayFollowUps = array_sum($todayFollowUpCount);

        // today's follow-ups table data
        $todayFollowUpData = $this->followUpModel->getTodaysFollowUps();


        $weeklySalesQuery = "
            SELECT DATE(payment_date) AS date, SUM(amount) AS total
            FROM lead_payments
            WHERE payment_status='paid' AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY DATE(payment_date)
            ORDER BY DATE(payment_date)
        ";
        $weeklySalesResult = $this->db->query($weeklySalesQuery);
        $weeklySales = [];
        while ($row = $weeklySalesResult->fetch_assoc()) {
            $weeklySales[] = [
                'date' => $row['date'],
                'total' => (float)$row['total']
            ];
        }

        // MONTHLY SALES (Last 30 days)
        $monthlySalesQuery = "
    SELECT DATE(payment_date) AS date, SUM(amount) AS total
    FROM lead_payments
    WHERE payment_status='paid' AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY DATE(payment_date)
    ORDER BY DATE(payment_date)
";
        $monthlySalesResult = $this->db->query($monthlySalesQuery);
        $monthlySales = [];
        while ($row = $monthlySalesResult->fetch_assoc()) {
            $monthlySales[] = [
                'date' => $row['date'],
                'total' => (float)$row['total']
            ];
        }

        // YEARLY SALES (Last 12 months)
        $yearlySalesQuery = "
    SELECT DATE_FORMAT(payment_date, '%Y-%m') AS month, SUM(amount) AS total
    FROM lead_payments
    WHERE payment_status='paid' AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
    GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
    ORDER BY DATE_FORMAT(payment_date, '%Y-%m')
";
        $yearlySalesResult = $this->db->query($yearlySalesQuery);
        $yearlySales = [];
        while ($row = $yearlySalesResult->fetch_assoc()) {
            $yearlySales[] = [
                'month' => $row['month'],
                'total' => (float)$row['total']
            ];
        }

        $totalProjects = $this->projectModel->countProject();




        $flatSalesQuery = "
    SELECT p.name AS project_name, COUNT(lb.id) AS flat_sold
    FROM lead_bookings lb
    JOIN projects p ON p.id = lb.project_id
    WHERE lb.booking_status = 'booked'
    AND lb.deleted_at IS NULL
    GROUP BY lb.project_id
    ORDER BY flat_sold DESC
";

        $result = $this->db->query($flatSalesQuery);

        $flatSalesLabels = [];
        $flatSalesSeries = [];

        while ($row = $result->fetch_assoc()) {
            $flatSalesLabels[] = $row['project_name'];
            $flatSalesSeries[] = (int)$row['flat_sold'];
        }


        // search project report 

        // Pass variables to view
        $this->view("sales-developments/salesTeamHead-dashboard", [
            "current_route" => "sales-team-head-dashboard",
            "page_title" => "Sales Dashboard",
            "totalLeadsCount" => $totalLeadsCount,
            "todayLeads" => $todayLeads,
            "followUpsDue" => $followUpsDue,
            "onboardedClients" => $onboardedClients,
            "bookingCollected" => $bookingCollected,
            "conversionRate" => $conversionRate,
            "newFollowUpsToday" => $newFollowUpsToday,
            "weeklySales" => $weeklySales,
            "monthlySales" => $monthlySales,
            "yearlySales" => $yearlySales,
            "totalProjects" => $totalProjects,
            "todayFollowUpData" => $todayFollowUpData,
            "totalTodayFollowUps" => $totalTodayFollowUps,
            "flatSalesLabels" => $flatSalesLabels,
            "flatSalesSeries" => $flatSalesSeries,


        ]);
    }

    public function salesTeamView()
    {

        $searchTerm = $_GET['q'] ?? '';
        $roleFilter = $_GET['role'] ?? '';

        $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $perPage = 10;
        $offset = ($currentPage - 1) * $perPage;

        // Total user count with filters
        $totalUsers = $this->userModel->countAllForSales($searchTerm, $roleFilter);
        $totalPages = ceil($totalUsers / $perPage);

        // Get paginated users with search & role filter
        $salesUsers = $this->userModel->getPaginatedWithSales($perPage, $offset, $searchTerm, $roleFilter);

        // Roles for filter dropdown
        $roles = $this->roleModel->getAll();
        $this->view('sales-developments/salesTeamHead/sales-team-views', [
            "current_route" => "sales-team-view",
            "page_title" => "Sales Team",
            'salesUsers' => $salesUsers,
            'roles' => $roles,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,


        ]);
    }

public function salesReport()
{
    // GET filters
    $selectedProject = $_GET['project_id'] ?? '';
    $selectedUser = $_GET['sales_by_id'] ?? '';
    $searchTerm = $_GET['q'] ?? ''; // optional search input if needed

    // Data load with project, user, search filters
    $dailySalesReport = $this->bookingModel->getSalesReport('daily', $searchTerm, $selectedProject, $selectedUser);
    $monthylySalesReport = $this->bookingModel->getSalesReport('monthly', $searchTerm, $selectedProject, $selectedUser);
    $yearlySalesReport = $this->bookingModel->getSalesReport('yearly', $searchTerm, $selectedProject, $selectedUser);

    $projects = $this->projectModel->getAll();
    $executiveUsers = $this->userModel->getAllRoleUser();

    $this->view('sales-developments/salesReport/sales-report', [
        'current_route' => 'sales-report',
        'page_title' => 'Sales Report',
        'dailySalesReport' => $dailySalesReport,
        'monthylySalesReport' => $monthylySalesReport,
        'yearlySalesReport' => $yearlySalesReport,
        "projects" => $projects,
        "selectedProject" => $selectedProject,
        "selectedUser" => $selectedUser,
        "executiveUsers" => $executiveUsers,
        "searchTerm" => $searchTerm,
    ]);
}

}

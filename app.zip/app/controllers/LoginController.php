<?php
class LoginController extends Controller
{
    protected $db;

    protected $userModel;

    public function __construct($db)
    {
        $this->db = $db;
        $this->userModel = new User($this->db);
    }


    public function index()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $message = "";



        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if (empty($email) || empty($password)) {
                $message = "Email and Password are required!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message = "Invalid Email Format!";
            } else {

                $user = $this->userModel->getByEmail($email);

                if ($user && password_verify($password, $user['password'])) {

                    session_regenerate_id(true);

                    $_SESSION['user'] = [
                        "id" => $user['id'],
                        "name" => $user["full_name"],
                        "user_name" => $user["user_name"],
                        "email" => $user["email"],
                        "role_id" => $user["role_id"],
                        "employee_id" => $user["employee_id"] ?? '',
                        "role_name" => strtolower($user['role_name'] ?? ''),
                    ];

                    $_SESSION['user']['permissions'] =
                        $this->userModel->getPermissionsByRole($user['role_id']);

                    // redirect logic...
                } else {
                    $message = "Invalid Email or Password!";
                }
            }
        }


        $this->view("auth/login", [
            "current_route" => "admin-login",
            "page_title" => "Admin Login",
            "message" => $message,
        ], false); // false = don't use master layout
    }


    public function logout()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['user']['id'])) {
            $userId = $_SESSION['user']['id'];
            $stmt = $this->db->prepare("UPDATE users SET last_logout = NOW() WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
        }

        // Destroy session
        session_unset();
        session_destroy();

        // Redirect to login page
        header("Location: {$GLOBALS['base_url']}/admin-login");
        exit;
    }
}

<?php
// Disable layout for this page
$disable_layout = true;

/**
 * Convert number to words (for Bangladeshi currency)
 */
function numberToWords($number)
{
    $number = (float)$number;

    if ($number == 0) {
        return 'Zero Taka Only';
    }

    $integerPart = floor($number);
    $decimalPart = round(($number - $integerPart) * 100);

    $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
    $teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    $result = '';

    if ($integerPart >= 10000000) {
        $crore = floor($integerPart / 10000000);
        $result .= convertHelper($crore, $ones, $teens, $tens) . ' Crore ';
        $integerPart %= 10000000;
    }

    if ($integerPart >= 100000) {
        $lakh = floor($integerPart / 100000);
        $result .= convertHelper($lakh, $ones, $teens, $tens) . ' Lakh ';
        $integerPart %= 100000;
    }

    if ($integerPart >= 1000) {
        $thousand = floor($integerPart / 1000);
        $result .= convertHelper($thousand, $ones, $teens, $tens) . ' Thousand ';
        $integerPart %= 1000;
    }

    if ($integerPart >= 100) {
        $hundred = floor($integerPart / 100);
        $result .= $ones[$hundred] . ' Hundred ';
        $integerPart %= 100;
    }

    if ($integerPart > 0) {
        $result .= convertHelper($integerPart, $ones, $teens, $tens);
    }

    $result = trim($result) . ' Taka';

    if ($decimalPart > 0) {
        $result .= ' and ' . convertHelper($decimalPart, $ones, $teens, $tens) . ' Paisa';
    }

    return trim($result) . ' Only';
}

function convertHelper($number, $ones, $teens, $tens)
{
    $result = '';

    if ($number < 10) {
        $result = $ones[$number];
    } elseif ($number < 20) {
        $result = $teens[$number - 10];
    } elseif ($number < 100) {
        $result = $tens[floor($number / 10)] . ' ' . $ones[$number % 10];
    } else {
        $result = $ones[floor($number / 100)] . ' Hundred ' . convertHelper($number % 100, $ones, $teens, $tens);
    }

    return trim($result);
}

// Convert amount to words
$amountInWords = numberToWords($transaction['amount'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cash Out Invoice - #<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= $GLOBALS['base_url'] ?>/public/assets/css/invoice.css">
</head>

<body>
    <div class="action-buttons no-print">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> Print Invoice
        </button>
        <button onclick="downloadPDF()" class="btn btn-success">
            <i class="fas fa-download"></i> Download PDF
        </button>
        <a href="<?= $GLOBALS['base_url'] ?>/management-cash-out" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <div class="invoice-container" id="invoice-content">
        <!-- Header -->
        <div class="invoice-header">
            <div class="company-info">
                <div class="company-logo">
                    <h1>The Premium Homes Ltd.</h1>
                </div>
                <div class="invoice-title">
                    <h2>CASH OUT RECEIPT</h2>
                </div>
            </div>
        </div>
        <div class="invoice-middle-header">
            <div class="company-info">
                <div class="company-logo">
                    <p>Real Estate & Property Management</p>
                    <p>Land View Commercial Center, 9th Floor 28 Gulshan North C/A, <br> Gulshan Circle-2, Dhaka</p>
                    <p>Phone: +8801958253300</p>
                    <p>Email: info@thepremiumhomes.com</p>
                </div>
                <div class="invoice-title">
                    <p class="invoice-number">#CO-<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></p>
                    <p class="invoice-number">Date: <?= date('d M, Y', strtotime($transaction['transaction_date'] ?? 'now')) ?></p>
                    <?php
                    $status = $transaction['payment_status'] ?? 'paid';
                    if ($status === 'paid'): ?>
                        <span class="paid-stamp">PAID</span>
                    <?php else: ?>
                        <span class="pending-stamp">PENDING</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Category & Transaction Details -->
        <div class="invoice-details">
            <div class="detail-section">
                <h3>Category Information</h3>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">
                        <?= htmlspecialchars($transaction['category_name'] ?? 'N/A') ?>
                    </span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Paid To:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['paid_to'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Transaction ID:</span>
                    <span class="detail-value">CO-<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></span>
                </div>
            </div>

            <div class="detail-section">
                <h3>Transaction Information</h3>
                <div class="detail-row">
                    <span class="detail-label">Transaction Date:</span>
                    <span class="detail-value"><?= date('d M, Y', strtotime($transaction['transaction_date'] ?? 'now')) ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Created By:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['created_by_name'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Created At:</span>
                    <span class="detail-value"><?= date('d M, Y h:i A', strtotime($transaction['created_at'] ?? 'now')) ?></span>
                </div>
            </div>
        </div>

        <!-- Payment Details -->
        <div class="payment-details">
            <h3>Payment Details</h3>
            <div class="payment-row">
                <span>Transaction Date:</span>
                <span style="font-weight: 600;"><?= date('d M, Y', strtotime($transaction['transaction_date'] ?? 'now')) ?></span>
            </div>
            <div class="payment-row">
                <span>Payment Method:</span>
                <span style="font-weight: 600;"><?= strtoupper($transaction['payment_method'] ?? 'CASH') ?></span>
            </div>
            <div class="payment-row">
                <span>Payment Status:</span>
                <span style="font-weight: 600;">
                    <?php
                    $status = $transaction['payment_status'] ?? 'paid';
                    if ($status === 'paid'): ?>
                        <span style="color: #27ae60;">PAID</span>
                    <?php elseif ($status === 'pending'): ?>
                        <span style="color: #f39c12;">PENDING</span>
                    <?php else: ?>
                        <span style="color: #e74c3c;"><?= strtoupper($status) ?></span>
                    <?php endif; ?>
                </span>
            </div>
            <?php if (!empty($transaction['transaction_ref'])): ?>
                <div class="payment-row">
                    <span>Transaction Reference:</span>
                    <span style="font-weight: 600;"><?= htmlspecialchars($transaction['transaction_ref']) ?></span>
                </div>
            <?php endif; ?>
            <div class="payment-row total">
                <span>Amount:</span>
                <span class="amount-highlight">৳<?= number_format($transaction['amount'] ?? 0, 2) ?></span>
            </div>
        </div>

        <!-- Amount in Words -->
        <div class="amount-in-words">
            <strong>Amount in Words:</strong> <?= $amountInWords ?>
        </div>

        <!-- Payment Method Details -->
        <?php if ($transaction['payment_method'] !== 'cash'): ?>
            <div class="payment-method-details">
                <h4>Payment Method: <?= strtoupper($transaction['payment_method'] ?? 'N/A') ?></h4>
                <div class="method-info">
                    <?php if ($transaction['payment_method'] === 'bank'): ?>
                        <?php if (!empty($transaction['bank_name'])): ?>
                            <div class="method-item">
                                <span class="detail-label">Bank Name:</span>
                                <span class="detail-value"><?= htmlspecialchars($transaction['bank_name']) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($transaction['bank_account_no'])): ?>
                            <div class="method-item">
                                <span class="detail-label">Account Number:</span>
                                <span class="detail-value"><?= htmlspecialchars($transaction['bank_account_no']) ?></span>
                            </div>
                        <?php endif; ?>
                    <?php elseif ($transaction['payment_method'] === 'cheque'): ?>
                        <?php if (!empty($transaction['cheque_no'])): ?>
                            <div class="method-item">
                                <span class="detail-label">Cheque Number:</span>
                                <span class="detail-value"><?= htmlspecialchars($transaction['cheque_no']) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($transaction['bank_name'])): ?>
                            <div class="method-item">
                                <span class="detail-label">Bank Name:</span>
                                <span class="detail-value"><?= htmlspecialchars($transaction['bank_name']) ?></span>
                            </div>
                        <?php endif; ?>
                    <?php elseif ($transaction['payment_method'] === 'online'): ?>
                        <?php if (!empty($transaction['online_type'])): ?>
                            <div class="method-item">
                                <span class="detail-label">Online Service:</span>
                                <span class="detail-value"><?= htmlspecialchars($transaction['online_type']) ?></span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Description -->
        <?php if (!empty($transaction['description'])): ?>
            <div class="notes-section">
                <h4>Transaction Description</h4>
                <p><?= nl2br(htmlspecialchars($transaction['description'])) ?></p>
            </div>
        <?php endif; ?>

        <!-- Signature Section -->
        <div class="signature-section">
            <div class="signature-box">
                <div class="signature-line">Authorized Signature</div>
                <p style="font-size: 12px; color: #7f8c8d; margin-top: 5px;">Company Representative</p>
            </div>
            <div class="signature-box">
                <div class="signature-line">Receiver Signature</div>
                <p style="font-size: 12px; color: #7f8c8d; margin-top: 5px;"><?= htmlspecialchars($transaction['paid_to'] ?? 'Recipient') ?></p>
            </div>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script>
      function downloadPDF() {
            const element = document.getElementById('invoice-content');

            // Add PDF mode
            document.body.classList.add('pdf-mode');

            const opt = {
                filename: 'Payment-Receipt-<?= str_pad($payment['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?>-<?= date('Ymd') ?>.pdf',
                image: {
                    type: 'jpeg',
                    quality: 0.98
                },
                html2canvas: {
                    scale: 2,
                    logging: false
                },
                jsPDF: {
                    unit: 'mm',
                    format: 'a4',
                    orientation: 'portrait'
                }
            };

            html2pdf()
                .set(opt)
                .from(element)
                .save()
                .then(() => {
                    // Remove PDF mode after download
                    document.body.classList.remove('pdf-mode');
                });

          }
    </script>
</body>

</html>
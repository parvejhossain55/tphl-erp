<?php
class CentralStatement extends Model
{
    protected $db;

    public function __construct($db)
    {
        $this->db = $db;
    }
    /**
     * Get total management cashin
     */
    private function getTotalManagementCashin($startDate, $endDate)
    {
        $query = "
        SELECT COALESCE(SUM(amount), 0) as total
        FROM management_cashin
        WHERE payment_status = 'paid'
        AND transaction_date BETWEEN ? AND ?
    ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total'] ?? 0);
    }

    /**
     * Get management cashin breakdown
     */
    private function getManagementCashinBreakdown($startDate, $endDate)
    {
        $query = "
        SELECT 
            id,
            transaction_date,
            role_name,
            person_name,
            amount,
            payment_method,
            source,
            description
        FROM management_cashin
        WHERE payment_status = 'paid'
        AND transaction_date BETWEEN ? AND ?
        ORDER BY transaction_date DESC
    ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();

        $breakdown = [];
        $totalAmount = 0;

        while ($row = $result->fetch_assoc()) {
            $amount = (float)$row['amount'];
            $breakdown[] = [
                'id' => $row['id'],
                'transaction_date' => $row['transaction_date'],
                'role_name' => $row['role_name'],
                'person_name' => $row['person_name'],
                'amount' => $amount,
                'payment_method' => $row['payment_method'],
                'source' => $row['source'],
                'description' => $row['description']
            ];
            $totalAmount += $amount;
        }

        return [
            'breakdown' => $breakdown,
            'total_amount' => $totalAmount,
            'transaction_count' => count($breakdown)
        ];
    }
    public function calculateRevenue($startDate, $endDate, $projectId = null)
    {
        // Get all required totals
        $totalLandShare = $this->getTotalLandShare($startDate, $endDate, $projectId);
        $totalDiscount = $this->getTotalDiscount($startDate, $endDate, $projectId);
        $totalBookingMoney = $this->getTotalBookingMoney($startDate, $endDate, $projectId);
        $totalServiceFee = $this->getTotalServiceFee($startDate, $endDate, $projectId);
        $totalManagementCashin = $this->getTotalManagementCashin($startDate, $endDate); // ADDED

        // Get individual payment type totals for cashin calculation
        $landsharePayments = $this->getTotalPaymentByType('land_share', $startDate, $endDate, $projectId);
        $registrationPayments = $this->getTotalPaymentByType('registration', $startDate, $endDate, $projectId);
        $emiPayments = $this->getTotalPaymentByType('emi', $startDate, $endDate, $projectId);
        $bookingMoneyPayments = $this->getTotalPaymentByType('booking_money', $startDate, $endDate, $projectId);

        // Calculate cashin according to formula (INCLUDES management_cashin)
        $totalCashin = $landsharePayments + $registrationPayments +
            $totalBookingMoney + $emiPayments + $totalManagementCashin; // ADDED management_cashin

        // Calculate revenue according to formula (REMOVED discount from revenue)
        // NEW: Remove discount from revenue calculation
        $totalRevenue = $totalLandShare + $totalBookingMoney + $totalServiceFee; // REMOVED - $totalDiscount

        // Additional breakdowns
        $paymentBreakdown = $this->getPaymentBreakdown($startDate, $endDate, $projectId);
        $emiBreakdown = $this->getEMIBreakdown($startDate, $endDate, $projectId);
        $landShareBreakdown = $this->getLandShareBreakdown($startDate, $endDate, $projectId);
        $managementCashinBreakdown = $this->getManagementCashinBreakdown($startDate, $endDate); // ADDED

        return [
            'summary' => [
                'total_landshare_from_payments' => $totalLandShare,
                'total_landshare_payments' => $landsharePayments,
                'total_registration_payments' => $registrationPayments,
                'total_emi_payments' => $emiPayments,
                'total_booking_money_payments' => $bookingMoneyPayments,
                'total_discount_from_bookings' => $totalDiscount,
                'total_service_fee' => $totalServiceFee,
                'total_management_cashin' => $totalManagementCashin, // ADDED
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue,
                'revenue_percentage' => $totalCashin > 0 ? ($totalRevenue / $totalCashin) * 100 : 0
            ],
            'payment_breakdown' => $paymentBreakdown,
            'emi_breakdown' => $emiBreakdown,
            'landshare_breakdown' => $landShareBreakdown,
            'management_cashin_breakdown' => $managementCashinBreakdown, // ADDED
            'period' => [
                'start_date' => $startDate,
                'end_date' => $endDate
            ]
        ];
    }

    private function getTotalPaymentByType($paymentType, $startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(lp.amount), 0) as total_amount
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE lp.payment_date BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = ?
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("sssi", $startDate, $endDate, $paymentType, $projectId);
        } else {
            $stmt->bind_param("sss", $startDate, $endDate, $paymentType);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_amount'] ?? 0);
    }

    private function getTotalLandShare($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(lp.land_share_amount), 0) as total_landshare
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE lp.payment_date BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = 'land_share'
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_landshare'] ?? 0);
    }


    private function getTotalBookingMoney($startDate, $endDate, $projectId = null)
    {
        $query = "
        SELECT COALESCE(SUM(lp.amount), 0) as total_booking_money
        FROM lead_payments lp
        INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
        WHERE lp.payment_date BETWEEN ? AND ?
        AND lp.payment_status = 'paid'
        AND lp.payment_type = 'booking_money'
    ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_booking_money'] ?? 0);
    }

    private function getTotalServiceFee($startDate, $endDate, $projectId = null)
    {
        if ($projectId) {
            $query = "
                SELECT COALESCE(SUM(es.service_fee), 0) as total_service_fee
                FROM emi_schedules es
                INNER JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE es.due_date BETWEEN ? AND ?
                AND es.status = 'paid'
                AND lb.project_id = ?
            ";
        } else {
            $query = "
                SELECT COALESCE(SUM(service_fee), 0) as total_service_fee
                FROM emi_schedules
                WHERE due_date BETWEEN ? AND ?
                AND status = 'paid'
            ";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_service_fee'] ?? 0);
    }

    private function getPaymentBreakdown($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT 
                lp.payment_type,
                COALESCE(SUM(lp.amount), 0) as total_amount,
                COUNT(*) as payment_count
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE lp.payment_date BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $query .= " GROUP BY lp.payment_type ORDER BY total_amount DESC";

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $breakdown = [];
        $grandTotal = 0;
        while ($row = $result->fetch_assoc()) {
            $amount = (float)$row['total_amount'];
            $breakdown[] = [
                'payment_type' => $row['payment_type'],
                'total_amount' => $amount,
                'payment_count' => (int)$row['payment_count']
            ];
            $grandTotal += $amount;
        }

        return [
            'breakdown' => $breakdown,
            'grand_total' => $grandTotal
        ];
    }

    private function getEMIBreakdown($startDate, $endDate, $projectId = null)
    {
        if ($projectId) {
            $query = "
                SELECT 
                    es.lead_booking_id,
                    COALESCE(SUM(es.emi_amount), 0) as total_emi,
                    COALESCE(SUM(es.service_fee), 0) as total_service_fee,
                    COUNT(*) as emi_count
                FROM emi_schedules es
                INNER JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE es.due_date BETWEEN ? AND ?
                AND es.status = 'paid'
                AND lb.project_id = ?
                GROUP BY es.lead_booking_id
                ORDER BY total_emi DESC
            ";
        } else {
            $query = "
                SELECT 
                    lead_booking_id,
                    COALESCE(SUM(emi_amount), 0) as total_emi,
                    COALESCE(SUM(service_fee), 0) as total_service_fee,
                    COUNT(*) as emi_count
                FROM emi_schedules
                WHERE due_date BETWEEN ? AND ?
                AND status = 'paid'
                GROUP BY lead_booking_id
                ORDER BY total_emi DESC
            ";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $breakdown = [];
        $totalEmi = 0;
        $totalServiceFee = 0;
        $totalCount = 0;

        while ($row = $result->fetch_assoc()) {
            $emi = (float)$row['total_emi'];
            $serviceFee = (float)$row['total_service_fee'];
            $breakdown[] = [
                'booking_id' => $row['lead_booking_id'],
                'total_emi' => $emi,
                'total_service_fee' => $serviceFee,
                'emi_count' => (int)$row['emi_count']
            ];
            $totalEmi += $emi;
            $totalServiceFee += $serviceFee;
            $totalCount += (int)$row['emi_count'];
        }

        return [
            'breakdown' => $breakdown,
            'totals' => [
                'total_emi' => $totalEmi,
                'total_service_fee' => $totalServiceFee,
                'total_count' => $totalCount
            ]
        ];
    }

    private function getLandShareBreakdown($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT 
                lp.booking_id,
                lp.payment_date,
                lp.land_share_amount,
                lp.amount as total_payment,
                lb.lead_id,
                lb.project_id
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE lp.payment_date BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = 'land_share'
            AND lp.land_share_amount > 0
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $query .= " ORDER BY lp.payment_date DESC";

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $breakdown = [];
        $totalLandShare = 0;

        while ($row = $result->fetch_assoc()) {
            $landShare = (float)$row['land_share_amount'];
            $breakdown[] = [
                'booking_id' => $row['booking_id'],
                'payment_date' => $row['payment_date'],
                'land_share_amount' => $landShare,
                'total_payment' => (float)$row['total_payment'],
                'lead_id' => $row['lead_id'],
                'project_id' => $row['project_id']
            ];
            $totalLandShare += $landShare;
        }

        return [
            'breakdown' => $breakdown,
            'total_landshare' => $totalLandShare,
            'transaction_count' => count($breakdown)
        ];
    }

    private function getTotalDiscount($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(discount_amount), 0) as total_discount
            FROM lead_bookings
            WHERE booking_date BETWEEN ? AND ?
            AND booking_status = 'booked'
            AND landshare_status = 'active'
        ";

        if ($projectId) {
            $query .= " AND project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_discount'] ?? 0);
    }

    /**
     * Get monthly statement (daily breakdown)
     */
    public function getEnhancedMonthlyStatement($year, $month, $projectId = null)
    {
        // Get the regular monthly statement
        $monthlyStatement = $this->getMonthlyStatement($year, $month, $projectId, 'all');

        // Calculate revenue for the month
        $monthPadded = sprintf("%02d", $month);
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $daysPadded = sprintf("%02d", $daysInMonth);

        $startDate = "$year-$monthPadded-01";
        $endDate = "$year-$monthPadded-$daysPadded";

        $revenueData = $this->calculateRevenue($startDate, $endDate, $projectId);

        // Combine both results
        return [
            'period' => $monthlyStatement['period'],
            'start_date' => $monthlyStatement['start_date'],
            'end_date' => $monthlyStatement['end_date'],
            'daily_data' => $monthlyStatement['daily_data'],
            'financial_summary' => [
                'cash_flow' => $monthlyStatement['summary'],
                'revenue_analysis' => $revenueData['summary'],
                'payment_breakdown' => $revenueData['payment_breakdown'],
                'emi_breakdown' => $revenueData['emi_breakdown'],
                'landshare_breakdown' => $revenueData['landshare_breakdown']
            ]
        ];
    }

    public function getRevenueStatistics($periodType = 'monthly', $year = null, $month = null, $startDate = null, $endDate = null, $projectId = null)
    {
        // Build date range based on period type
        if ($periodType === 'monthly' && $year && $month) {
            $monthPadded = sprintf("%02d", $month);
            $startDate = "$year-$monthPadded-01";
            $endDate = date('Y-m-t', strtotime($startDate));
        } elseif ($periodType === 'yearly' && $year) {
            $startDate = "$year-01-01";
            $endDate = "$year-12-31";
        } elseif ($periodType === 'custom' && $startDate && $endDate) {
            // Use provided dates
        } else {
            // Default to current month
            $startDate = date('Y-m-01');
            $endDate = date('Y-m-t');
        }

        // Get revenue calculation
        $revenueData = $this->calculateRevenue($startDate, $endDate, $projectId);

        // Get cash flow data
        $cashFlowData = $this->getOverallStatistics($periodType, $year, $month, $startDate, $endDate, $projectId, 'all');

        return [
            'period' => [
                'type' => $periodType,
                'start_date' => $startDate,
                'end_date' => $endDate,
                'year' => $year,
                'month' => $month
            ],
            'revenue_summary' => $revenueData['summary'],
            'cash_flow_summary' => $cashFlowData,
            'key_metrics' => [
                'profitability_ratio' => $revenueData['summary']['revenue_percentage'],
                'cash_to_revenue_ratio' => $cashFlowData['total_cashin'] > 0 ?
                    ($revenueData['summary']['total_revenue'] / $cashFlowData['total_cashin']) * 100 : 0,
                'average_transaction_value' => $revenueData['payment_breakdown']['grand_total'] > 0 &&
                    $revenueData['payment_breakdown']['breakdown'] ?
                    $revenueData['payment_breakdown']['grand_total'] / count($revenueData['payment_breakdown']['breakdown']) : 0
            ]
        ];
    }

    public function getMonthlyStatement($year, $month, $projectId = null, $category = 'all')
    {
        $year = (int)$year;
        $month = (int)$month;
        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $monthPadded = sprintf("%02d", $month);
        $daysPadded = sprintf("%02d", $daysInMonth);

        $startDate = "$year-$monthPadded-01";
        $endDate = "$year-$monthPadded-$daysPadded";

        // Get opening balance
        $openingBalance = $this->getOpeningBalance($startDate, $projectId, $category);

        // Get payment breakdown by type
        $landsharePaymentsData = $this->getDailyPaymentByType('land_share', $startDate, $endDate, $projectId);
        $registrationPaymentsData = $this->getDailyPaymentByType('registration', $startDate, $endDate, $projectId);
        $emiPaymentsData = $this->getDailyPaymentByType('emi', $startDate, $endDate, $projectId);
        $bookingMoneyData = $this->getDailyBookingMoney($startDate, $endDate, $projectId);
        $serviceFeeData = $this->getDailyServiceFees($startDate, $endDate, $projectId);
        $managementCashinData = $this->getDailyManagementCashins($startDate, $endDate); // Already exists
        $discountData = $this->getDailyDiscounts($startDate, $endDate, $projectId);
        $cashOutData = $this->getCashOutData($startDate, $endDate, $category, $projectId);

        // Build daily statement
        $dailyStatement = [];
        $runningBalance = $openingBalance;

        // Initialize totals
        $totals = [
            'landshare_payments' => 0,
            'registration_payments' => 0,
            'emi_payments' => 0,
            'booking_money' => 0,
            'service_fee' => 0,
            'management_cashin' => 0,
            'discount' => 0,
            'cash_out' => 0
        ];

        for ($day = 1; $day <= $daysInMonth; $day++) {
            $dayPadded = sprintf("%02d", $day);
            $date = "$year-$monthPadded-$dayPadded";

            // Get daily amounts
            $landsharePayments = $landsharePaymentsData[$date] ?? 0;
            $registrationPayments = $registrationPaymentsData[$date] ?? 0;
            $emiPayments = $emiPaymentsData[$date] ?? 0;
           $bookingMoney = $bookingMoneyData[$date] ?? 0;
            $serviceFee = $serviceFeeData[$date] ?? 0;
            $managementCashin = $managementCashinData[$date] ?? 0;
            $discount = $discountData[$date] ?? 0;

            // Calculate cashin based on selected category
            $cashin = 0;
            if ($category === 'all' || $category === 'total_cashin') {
                // Total cashin includes all revenue sources INCLUDING management_cashin minus discount
                $cashin = $landsharePayments + $registrationPayments + $bookingMoney + $emiPayments + $managementCashin; // ADDED management_cashin
            } elseif ($category === 'emi') {
                $cashin = $emiPayments;
            } elseif ($category === 'landshare') {
                $cashin = $landsharePayments;
            } elseif ($category === 'registration') {
                $cashin = $registrationPayments;
            } elseif ($category === 'service_fee') {
                $cashin = $serviceFee;
            } elseif ($category === 'booking_money') {
                $cashin = $bookingMoney;
            } elseif ($category === 'management_cashin') {
                $cashin = $managementCashin;
            }

            $cashOut = $cashOutData[$date] ?? 0;
            $netAmount = $cashin - $cashOut;

            // Only update running balance for 'all' category
            if ($category === 'all') {
                $runningBalance += $netAmount;
            }

            // Accumulate totals
            $totals['landshare_payments'] += $landsharePayments;
            $totals['registration_payments'] += $registrationPayments;
            $totals['emi_payments'] += $emiPayments;
            $totals['booking_money'] += $bookingMoney;
            $totals['service_fee'] += $serviceFee;
            $totals['management_cashin'] += $managementCashin; // Accumulate
            $totals['discount'] += $discount;
            $totals['cash_out'] += $cashOut;

            $dailyStatement[] = [
                'date' => $date,
                'formatted_date' => date('d M, Y', strtotime($date)),
                'day_name' => date('l', strtotime($date)),
                'booking_money' => $bookingMoney,
                'registration' => $registrationPayments,
                'emi_payments' => $emiPayments,
                'landshare_payments' => $landsharePayments,
                'service_fee' => $serviceFee,
                'management_cashin' => $managementCashin, // Show in breakdown
                'discount' => $discount,
                'total_cashin' => $cashin,
                'cash_out' => $cashOut,
                'net_amount' => $netAmount,
                'running_balance' => $category === 'all' ? $runningBalance : $cashin,
            ];
        }

        // Calculate final totals based on category
        $totalCashin = 0;
        $totalRevenue = 0;

        if ($category === 'all' || $category === 'total_cashin') {
            // Include management_cashin in total cashin
            $totalCashin = $totals['landshare_payments'] + $totals['registration_payments'] +
                $totals['booking_money'] + $totals['emi_payments'] + $totals['management_cashin']; // ADDED management_cashin

            // Remove discount from revenue calculation
            $totalRevenue = $totals['landshare_payments'] + $totals['booking_money'] + $totals['service_fee']; // REMOVED - $totals['discount']
        } elseif ($category === 'emi') {
            $totalCashin = $totals['emi_payments'];
            $totalRevenue = $totals['emi_payments'];
        } elseif ($category === 'landshare') {
            $totalCashin = $totals['landshare_payments'];
            $totalRevenue = $totals['landshare_payments'];
        } elseif ($category === 'registration') {
            $totalCashin = $totals['registration_payments'];
            $totalRevenue = $totals['registration_payments'];
        } elseif ($category === 'service_fee') {
            $totalCashin = $totals['service_fee'];
            $totalRevenue = $totals['service_fee'];
        } elseif ($category === 'booking_money') {
            $totalCashin = $totals['booking_money'];
            $totalRevenue = $totals['booking_money'];
        } elseif ($category === 'management_cashin') {
            $totalCashin = $totals['management_cashin'];
            $totalRevenue = $totals['management_cashin'];
        }

        return [
            'period' => date('F Y', strtotime($startDate)),
            'start_date' => $startDate,
            'end_date' => $endDate,
            'opening_balance' => $openingBalance,
            'daily_data' => $dailyStatement,
            'summary' => [
                'total_booking_money' => $totals['booking_money'],
                'total_registration_payments' => $totals['registration_payments'],
                'total_emi_payments' => $totals['emi_payments'],
                'total_landshare_payments' => $totals['landshare_payments'],
                'total_service_fee' => $totals['service_fee'],
                'total_management_cashin' => $totals['management_cashin'], // Added to summary
                'total_discount' => $totals['discount'],
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue, // Now excludes discount
                'total_cash_out' => $totals['cash_out'],
                'net_balance' => $totalCashin - $totals['cash_out'],
                'final_balance' => $category === 'all' ? $runningBalance : $totalCashin
            ]
        ];
    }
    /**
     * Helper method to get amount based on category
     */
    private function getCategoryAmount($selectedCategory, $categoryType, $dataArray, $date)
    {
        // For total_cashin category, we need to return 0 for individual types
        // since total_cashin is calculated separately in the main method
        if ($selectedCategory === 'total_cashin') {
            return 0; // total_cashin is calculated in the main method, not from dataArray
        }

        if ($selectedCategory === 'all' || $selectedCategory === $categoryType) {
            return $dataArray[$date] ?? 0;
        }
        return 0;
    }
    private function getDailyPaymentByType($paymentType, $startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT 
                DATE(lp.payment_date) as transaction_date,
                SUM(lp.amount) as total_amount
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE DATE(lp.payment_date) BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = ?
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $query .= " GROUP BY DATE(lp.payment_date)";

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("sssi", $startDate, $endDate, $paymentType, $projectId);
        } else {
            $stmt->bind_param("sss", $startDate, $endDate, $paymentType);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['transaction_date']] = (float)$row['total_amount'];
        }
        return $data;
    }

    private function getDailyDiscounts($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT 
                DATE(booking_date) as transaction_date,
                SUM(discount_amount) as total_amount
            FROM lead_bookings
            WHERE DATE(booking_date) BETWEEN ? AND ?
            AND booking_status = 'booked'
            AND landshare_status = 'active'
        ";

        if ($projectId) {
            $query .= " AND project_id = ?";
        }

        $query .= " GROUP BY DATE(booking_date)";

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['transaction_date']] = (float)$row['total_amount'];
        }
        return $data;
    }

private function getDailyBookingMoney($startDate, $endDate, $projectId = null)
{
    $query = "
        SELECT 
            DATE(lp.payment_date) as transaction_date,
            SUM(lp.amount) as total_amount
        FROM lead_payments lp
        INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
        WHERE DATE(lp.payment_date) BETWEEN ? AND ?
        AND lp.payment_status = 'paid'
        AND lp.payment_type = 'booking_money'
    ";

    if ($projectId) {
        $query .= " AND lb.project_id = ?";
    }

    $query .= " GROUP BY DATE(lp.payment_date)";

    $stmt = $this->db->prepare($query);
    if ($projectId) {
        $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
    } else {
        $stmt->bind_param("ss", $startDate, $endDate);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[$row['transaction_date']] = (float)$row['total_amount'];
    }
    return $data;
}

    private function getDailyServiceFees($startDate, $endDate, $projectId = null)
    {
        if ($projectId) {
            $query = "
                SELECT 
                    DATE(es.due_date) as transaction_date,
                    SUM(es.service_fee) as total_amount
                FROM emi_schedules es
                INNER JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE DATE(es.due_date) BETWEEN ? AND ?
                AND es.status = 'paid'
                AND lb.project_id = ?
                GROUP BY DATE(es.due_date)
            ";
        } else {
            $query = "
                SELECT 
                    DATE(es.due_date) as transaction_date,
                    SUM(es.service_fee) as total_amount
                FROM emi_schedules es
                WHERE DATE(es.due_date) BETWEEN ? AND ?
                AND es.status = 'paid'
                GROUP BY DATE(es.due_date)
            ";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['transaction_date']] = (float)$row['total_amount'];
        }
        return $data;
    }

    private function getDailyManagementCashins($startDate, $endDate)
    {
        $query = "
            SELECT 
                DATE(transaction_date) as transaction_date,
                SUM(amount) as total_amount
            FROM management_cashin
            WHERE DATE(transaction_date) BETWEEN ? AND ?
            AND payment_status = 'paid'
            GROUP BY DATE(transaction_date)
        ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[$row['transaction_date']] = (float)$row['total_amount'];
        }
        return $data;
    }

    /**
     * Helper: Get cashout data (management_cashout + cashout_request payments) with category filtering
     */
    private function getCashOutData($startDate, $endDate, $category = 'all', $projectId = null)
    {
        if ($category === 'utilities') {
            return $this->getUtilitiesCashOutData($startDate, $endDate, $projectId);
        }

        // Get management cashout
        $managementQuery = "
        SELECT 
            DATE(transaction_date) as transaction_date,
            SUM(amount) as total_amount
        FROM management_cashout
        WHERE DATE(transaction_date) BETWEEN ? AND ?
        AND payment_status = 'paid'
    ";

        $managementParams = [$startDate, $endDate];
        $managementTypes = "ss";

        if ($category !== 'all') {
            $categoryId = $this->getCategoryIdByName($category);
            if ($categoryId) {
                $managementQuery .= " AND category_id = ?";
                $managementParams[] = $categoryId;
                $managementTypes .= "i";
            }
        }

        $managementQuery .= " GROUP BY DATE(transaction_date)";

        $stmt = $this->db->prepare($managementQuery);
        if (!empty($managementParams)) {
            $stmt->bind_param($managementTypes, ...$managementParams);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $managementData = [];
        while ($row = $result->fetch_assoc()) {
            $managementData[$row['transaction_date']] = (float)$row['total_amount'];
        }

        // Get cashout request payments (only for 'cashout' category or 'all')
        $cashoutRequestData = [];
        if ($category === 'all' || $category === 'cashout') {
            $cashoutRequestQuery = "
            SELECT 
                DATE(cp.payment_date) as transaction_date,
                SUM(cp.amount) as total_amount
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            WHERE DATE(cp.payment_date) BETWEEN ? AND ?
            AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
        ";

            // Add project filter if specified
            if ($projectId) {
                $cashoutRequestQuery .= " AND (cr.project_id = ? OR cp.project_id = ?)";
                $cashoutRequestParams = [$startDate, $endDate, $projectId, $projectId];
                $cashoutRequestTypes = "ssii";
            } else {
                $cashoutRequestParams = [$startDate, $endDate];
                $cashoutRequestTypes = "ss";
            }

            $cashoutRequestQuery .= " GROUP BY DATE(cp.payment_date)";

            $stmt = $this->db->prepare($cashoutRequestQuery);
            if ($projectId) {
                $stmt->bind_param($cashoutRequestTypes, ...$cashoutRequestParams);
            } else {
                $stmt->bind_param($cashoutRequestTypes, ...$cashoutRequestParams);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $cashoutRequestData[$row['transaction_date']] = (float)$row['total_amount'];
            }
        }

        // Get salary payments (payslips) - only for 'all' category
        $payslipsData = [];
        if ($category === 'all') {
            $payslipsQuery = "
            SELECT 
                DATE(updated_at) as transaction_date,
                SUM(net_salary) as total_amount
            FROM payslips
            WHERE DATE(updated_at) BETWEEN ? AND ?
            AND status = 'paid'
            GROUP BY DATE(updated_at)
        ";

            $stmt = $this->db->prepare($payslipsQuery);
            $stmt->bind_param("ss", $startDate, $endDate);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $payslipsData[$row['transaction_date']] = (float)$row['total_amount'];
            }
        }

        // Combine all sources based on category
        $allDates = array_unique(array_merge(
            array_keys($managementData),
            array_keys($cashoutRequestData),
            array_keys($payslipsData)
        ));

        $combinedData = [];
        foreach ($allDates as $date) {
            $combinedData[$date] =
                ($managementData[$date] ?? 0) +
                ($cashoutRequestData[$date] ?? 0) +
                ($payslipsData[$date] ?? 0);
        }

        return $combinedData;
    }


    /**
     * Helper: Get Utilities cashout data from cashout_requests table based on keywords
     */
    private function getUtilitiesCashOutData($startDate, $endDate, $projectId = null)
    {
        // Keywords to identify utility bills
        $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

        // Build keyword condition
        $keywordConditions = [];
        foreach ($utilityKeywords as $keyword) {
            $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
        }
        $keywordCondition = implode(' OR ', $keywordConditions);

        $query = "
        SELECT 
            DATE(cp.payment_date) as transaction_date,
            SUM(cp.amount) as total_amount
        FROM cashout_payments cp
        LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
        WHERE DATE(cp.payment_date) BETWEEN ? AND ?
        AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
        AND ($keywordCondition)
    ";

        // Add project filter if specified
        if ($projectId) {
            $query .= " AND (cr.project_id = ? OR cp.project_id = ?)";
            $params = [$startDate, $endDate, $projectId, $projectId];
            $types = "ssii";
        } else {
            $params = [$startDate, $endDate];
            $types = "ss";
        }

        $query .= " GROUP BY DATE(cp.payment_date)";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        $utilitiesData = [];
        while ($row = $result->fetch_assoc()) {
            $utilitiesData[$row['transaction_date']] = (float)$row['total_amount'];
        }

        return $utilitiesData;
    }

    /**
     * Get 6-month statement (monthly breakdown)
     */
    public function getSixMonthStatement($endYear, $endMonth, $projectId = null, $category = 'all')
    {
        // Convert empty string to null
        if ($projectId === '') {
            $projectId = null;
        }

        $monthlyData = [];

        // Calculate 6 months back
        $startDate = date('Y-m-01', strtotime("-5 months", strtotime("$endYear-$endMonth-01")));
        $endDate = date('Y-m-t', strtotime("$endYear-$endMonth-01"));

        // Get opening balance before the 6-month period
        $runningBalance = $this->getOpeningBalance($startDate, $projectId, $category);

        // Initialize totals
        $totals = [
            'landshare_payments' => 0,
            'registration_payments' => 0,
            'emi_payments' => 0,
            'booking_money' => 0,
            'service_fee' => 0,
            'management_cashin' => 0,
            'discount' => 0,
            'cash_out' => 0
        ];

        for ($i = 5; $i >= 0; $i--) {
            $date = date('Y-m-01', strtotime("-$i months", strtotime("$endYear-$endMonth-01")));
            $year = date('Y', strtotime($date));
            $month = date('m', strtotime($date));
            $monthStart = "$year-$month-01";
            $monthEnd = date('Y-m-t', strtotime($monthStart));

            // Get monthly totals
            $landsharePayments = $this->getMonthlyPaymentByType('land_share', $monthStart, $monthEnd, $projectId);
            $registrationPayments = $this->getMonthlyPaymentByType('registration', $monthStart, $monthEnd, $projectId);
            $emiPayments = $this->getMonthlyPaymentByType('emi', $monthStart, $monthEnd, $projectId);
            $bookingMoney = $this->getMonthlyBookingMoney($monthStart, $monthEnd, $projectId);
            $serviceFee = $this->getMonthlyServiceFee($monthStart, $monthEnd, $projectId);
            $managementCashin = $this->getMonthlyManagementCashin($monthStart, $monthEnd);
            $discount = $this->getMonthlyDiscount($monthStart, $monthEnd, $projectId);

            // Only get cashout for expense categories, not for revenue categories
            $cashOut = 0;
            if (in_array($category, ['all', 'cashout', 'utilities', 'other'])) {
                $cashOut = $this->getMonthlyCashOut($monthStart, $monthEnd, $category);
            }

            // Calculate cashin according to formula
            // CORRECT - adding management_cashin
            $cashin = $landsharePayments + $registrationPayments + $bookingMoney + $emiPayments + $managementCashin;

            $netAmount = $cashin - $cashOut;
            $runningBalance += $netAmount;

            // Accumulate totals
            $totals['landshare_payments'] += $landsharePayments;
            $totals['registration_payments'] += $registrationPayments;
            $totals['emi_payments'] += $emiPayments;
            $totals['booking_money'] += $bookingMoney;
            $totals['service_fee'] += $serviceFee;
            $totals['management_cashin'] += $managementCashin;
            $totals['discount'] += $discount;
            $totals['cash_out'] += $cashOut;

            $monthlyData[] = [
                'month' => date('F Y', strtotime($date)),
                'year' => $year,
                'month_num' => $month,
                // Detailed breakdown
                'booking_money' => $bookingMoney,
                'registration_payments' => $registrationPayments,
                'emi_payments' => $emiPayments,
                'landshare_payments' => $landsharePayments, // Correct: actual landshare payments
                'service_fee' => $serviceFee,
                'management_cashin' => $managementCashin,
                'discount' => $discount,
                'total_cashin' => $cashin,
                'cash_out' => $cashOut,
                'net_amount' => $netAmount,
                'running_balance' => $runningBalance,
            ];
        }

        // Calculate final totals
        $totalCashin = $totals['landshare_payments'] + $totals['registration_payments'] +
            $totals['booking_money'] + $totals['emi_payments'] + $totals['management_cashin']; // Include management_cashin in total cashin;

        $totalRevenue = $totals['landshare_payments']  + $totals['booking_money'] + $totals['service_fee'];

        return [
            'period' => 'Last 6 Months',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'opening_balance' => $this->getOpeningBalance($startDate, $projectId, $category),
            'monthly_data' => $monthlyData,
            'summary' => [
                'total_registration_payments' => $totals['registration_payments'],
                'total_emi_payments' => $totals['emi_payments'],
                'total_booking_money' => $totals['booking_money'], // Fixed: Use actual booking money
                'total_service_fee' => $totals['service_fee'],
                'total_management_cashin' => $totals['management_cashin'],
                'total_discount' => $totals['discount'],
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue,
                'total_cash_out' => $totals['cash_out'],
                'net_balance' => $totalCashin - $totals['cash_out'],
                'final_balance' => $runningBalance,
            ]
        ];
    }

    private function getMonthlyPaymentByType($paymentType, $startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(lp.amount), 0) as total_amount
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE lp.payment_date BETWEEN ? AND ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = ?
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("sssi", $startDate, $endDate, $paymentType, $projectId);
        } else {
            $stmt->bind_param("sss", $startDate, $endDate, $paymentType);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_amount'] ?? 0);
    }

    private function getMonthlyDiscount($startDate, $endDate, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(discount_amount), 0) as total_discount
            FROM lead_bookings
            WHERE booking_date BETWEEN ? AND ?
            AND booking_status = 'booked'
            AND landshare_status = 'active'
        ";

        if ($projectId) {
            $query .= " AND project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_discount'] ?? 0);
    }

private function getMonthlyBookingMoney($startDate, $endDate, $projectId = null)
{
    $query = "
        SELECT COALESCE(SUM(lp.amount), 0) as total
        FROM lead_payments lp
        INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
        WHERE DATE(lp.payment_date) BETWEEN ? AND ?
        AND lp.payment_status = 'paid'
        AND lp.payment_type = 'booking_money'
    ";

    if ($projectId) {
        $query .= " AND lb.project_id = ?";
    }

    $stmt = $this->db->prepare($query);
    if ($projectId) {
        $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
    } else {
        $stmt->bind_param("ss", $startDate, $endDate);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return (float)($row['total'] ?? 0);
}

    private function getMonthlyServiceFee($startDate, $endDate, $projectId = null)
    {
        if ($projectId) {
            $query = "
                SELECT COALESCE(SUM(es.service_fee), 0) as total
                FROM emi_schedules es
                LEFT JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE DATE(es.due_date) BETWEEN ? AND ?
                AND es.status = 'paid'
                AND lb.project_id = ?
            ";
        } else {
            $query = "
                SELECT COALESCE(SUM(service_fee), 0) as total
                FROM emi_schedules
                WHERE DATE(due_date) BETWEEN ? AND ?
                AND status = 'paid'
            ";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $startDate, $endDate, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total'] ?? 0);
    }

    private function getMonthlyManagementCashin($startDate, $endDate)
    {
        $query = "
            SELECT COALESCE(SUM(amount), 0) as total
            FROM management_cashin
            WHERE DATE(transaction_date) BETWEEN ? AND ?
            AND payment_status = 'paid'
        ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total'] ?? 0);
    }

    /**
     * Get yearly statement (monthly breakdown for a year)
     */
    public function getYearlyStatement($year, $projectId = null, $category = 'all')
    {
        // Convert empty string to null
        if ($projectId === '') {
            $projectId = null;
        }

        $monthlyData = [];
        $startDate = "$year-01-01";

        // Get opening balance before the year
        $runningBalance = $this->getOpeningBalance($startDate, $projectId, $category);

        // Initialize totals
        $totals = [
            'landshare_payments' => 0,
            'registration_payments' => 0,
            'emi_payments' => 0,
            'booking_money' => 0,
            'service_fee' => 0,
            'management_cashin' => 0,
            'discount' => 0,
            'cash_out' => 0
        ];

        for ($month = 1; $month <= 12; $month++) {
            $monthStart = sprintf("%s-%02d-01", $year, $month);
            $monthEnd = date('Y-m-t', strtotime($monthStart));

            // Get monthly totals
            $landsharePayments = $this->getMonthlyPaymentByType('land_share', $monthStart, $monthEnd, $projectId);
            $registrationPayments = $this->getMonthlyPaymentByType('registration', $monthStart, $monthEnd, $projectId);
            $emiPayments = $this->getMonthlyPaymentByType('emi', $monthStart, $monthEnd, $projectId);
            $bookingMoney = $this->getMonthlyBookingMoney($monthStart, $monthEnd, $projectId);
            $serviceFee = $this->getMonthlyServiceFee($monthStart, $monthEnd, $projectId);
            $managementCashin = $this->getMonthlyManagementCashin($monthStart, $monthEnd);
            $discount = $this->getMonthlyDiscount($monthStart, $monthEnd, $projectId);

            // Only get cashout for expense categories, not for revenue categories
            $cashOut = 0;
            if (in_array($category, ['all', 'cashout', 'utilities', 'other'])) {
                $cashOut = $this->getMonthlyCashOut($monthStart, $monthEnd, $category);
            }

            // Calculate cashin according to formula
            $cashin = $landsharePayments + $registrationPayments + $bookingMoney + $emiPayments + $managementCashin;

            $netAmount = $cashin - $cashOut;
            $runningBalance += $netAmount;

            // Accumulate totals
            $totals['landshare_payments'] += $landsharePayments;
            $totals['registration_payments'] += $registrationPayments;
            $totals['emi_payments'] += $emiPayments;
            $totals['booking_money'] += $bookingMoney;
            $totals['service_fee'] += $serviceFee;
            $totals['management_cashin'] += $managementCashin;
            $totals['discount'] += $discount;
            $totals['cash_out'] += $cashOut;

            $monthlyData[] = [
                'month' => date('F Y', strtotime($monthStart)),
                'year' => $year,
                'month_num' => $month,
                // Detailed breakdown
                'booking_money' => $bookingMoney,
                'registration_payments' => $registrationPayments,
                'emi_payments' => $emiPayments,
                'landshare_payments' => $landsharePayments,
                'service_fee' => $serviceFee,
                'management_cashin' => $managementCashin,
                'discount' => $discount,
                'total_cashin' => $cashin,
                'cash_out' => $cashOut,
                'net_amount' => $netAmount,
                'running_balance' => $runningBalance,
                'total_revenue' => $cashin
            ];
        }

        // Calculate final totals
        $totalCashin = $totals['landshare_payments'] + $totals['registration_payments'] +
            $totals['booking_money'] + $totals['emi_payments'] + $totals['management_cashin'];

        $totalRevenue = $totals['landshare_payments']  +
            $totals['booking_money'] + $totals['service_fee'];

        return [
            'period' => "Year $year",
            'start_date' => "$year-01-01",
            'end_date' => "$year-12-31",
            'opening_balance' => $this->getOpeningBalance($startDate, $projectId, $category),
            'monthly_data' => $monthlyData,
            'summary' => [
                'total_booking_money' => $totals['booking_money'],
                'total_registration_payments' => $totals['registration_payments'],
                'total_emi_payments' => $totals['emi_payments'],
                'total_landshare_payments' => $totals['landshare_payments'],
                'total_service_fee' => $totals['service_fee'],
                'total_management_cashin' => $totals['management_cashin'],
                'total_discount' => $totals['discount'],
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue,
                'total_cash_out' => $totals['cash_out'],
                'net_balance' => $totalCashin - $totals['cash_out'],
                'final_balance' => $runningBalance,
                // Backward compatibility
                'total_landshare' => $totals['total_landshare_payments']
            ]
        ];
    }

    /**
     * Get custom range statement (daily if <= 31 days, monthly if > 31 days)
     */
    public function getCustomRangeStatement($startDate, $endDate, $projectId = null, $category = 'all')
    {
        $start = strtotime($startDate);
        $end = strtotime($endDate);
        $daysDiff = ($end - $start) / (60 * 60 * 24);

        if ($daysDiff <= 31) {
            return $this->getCustomDailyStatement($startDate, $endDate, $projectId, $category);
        } else {
            return $this->getCustomMonthlyStatement($startDate, $endDate, $projectId, $category);
        }
    }

    private function getCustomDailyStatement($startDate, $endDate, $projectId = null, $category = 'all')
    {
        $start = strtotime($startDate);
        $end = strtotime($endDate);
        $dailyData = [];

        // Get opening balance before the period
        $runningBalance = $this->getOpeningBalance($startDate, $projectId, $category);

        // Initialize totals
        $totals = [
            'landshare_payments' => 0,
            'registration_payments' => 0,
            'emi_payments' => 0,
            'booking_money' => 0,
            'service_fee' => 0,
            'management_cashin' => 0,
            'discount' => 0,
            'cash_out' => 0
        ];

        // Get data for each day
        for ($current = $start; $current <= $end; $current += 86400) {
            $date = date('Y-m-d', $current);

            // Get daily amounts
            $landsharePayments = $this->getDailyPaymentByTypeSingle('land_share', $date, $projectId);
            $registrationPayments = $this->getDailyPaymentByTypeSingle('registration', $date, $projectId);
            $emiPayments = $this->getDailyPaymentByTypeSingle('emi', $date, $projectId);
            $bookingMoney = $this->getDailyPaymentByTypeSingle('booking_money', $date, $projectId);

            $serviceFee = $this->getDailyServiceFeeSingle($date, $projectId);
            $managementCashin = $this->getDailyManagementCashinSingle($date);
            $discount = $this->getDailyDiscountSingle($date, $projectId);
            $cashOut = $this->getDailyCashOut($date, $category);

            // Calculate cashin based on selected category
            $cashin = 0;
            if ($category === 'all' || $category === 'total_cashin') {
                // Total cashin includes all revenue sources minus discount
                $cashin = $landsharePayments + $registrationPayments + $bookingMoney + $emiPayments + $managementCashin;
            } elseif ($category === 'emi') {
                $cashin = $emiPayments;
            } elseif ($category === 'landshare') {
                $cashin = $landsharePayments;
            } elseif ($category === 'registration') {
                $cashin = $registrationPayments;
            } elseif ($category === 'service_fee') {
                $cashin = $serviceFee;
            }  elseif ($category === 'booking_money') {
                $cashin = $bookingMoney;
            } elseif ($category === 'management_cashin') {
                $cashin = $managementCashin;
            }

            $netAmount = $cashin - $cashOut;

            // Only update running balance for 'all' category
            if ($category === 'all') {
                $runningBalance += $netAmount;
            }

            // Accumulate totals
            $totals['landshare_payments'] += $landsharePayments;
            $totals['registration_payments'] += $registrationPayments;
            $totals['emi_payments'] += $emiPayments;
            $totals['booking_money'] += $bookingMoney;
            $totals['service_fee'] += $serviceFee;
            $totals['management_cashin'] += $managementCashin;
            $totals['discount'] += $discount;
            $totals['cash_out'] += $cashOut;

            $dailyData[] = [
                'date' => $date,
                'formatted_date' => date('d M, Y', strtotime($date)),
                'day_name' => date('l', strtotime($date)),
                // Detailed breakdown
                'booking_money' => $bookingMoney,
                'registration_payments' => $registrationPayments,
                'emi_payments' => $emiPayments,
                'landshare_payments' => $landsharePayments,
                'service_fee' => $serviceFee,
                'management_cashin' => $managementCashin,
                'discount' => $discount,
                'total_cashin' => $cashin,
                'cash_out' => $cashOut,
                'net_amount' => $netAmount,
                'running_balance' => $category === 'all' ? $runningBalance : $cashin,
                // Backward compatibility
                'landshare' => $landsharePayments,
                'total_revenue' => $cashin
            ];
        }

        // Calculate final totals based on category
        $totalCashin = 0;
        $totalRevenue = 0;

        if ($category === 'all' || $category === 'total_cashin') {
            $totalCashin = $totals['landshare_payments'] + $totals['registration_payments'] +
                $totals['booking_money'] + $totals['emi_payments'] + $totals['management_cashin'];
            $totalRevenue = $totals['landshare_payments'] + $totals['booking_money'] + $totals['service_fee'];
        } elseif ($category === 'emi') {
            $totalCashin = $totals['emi_payments'];
            $totalRevenue = $totals['emi_payments'];
        } elseif ($category === 'landshare') {
            $totalCashin = $totals['landshare_payments'];
            $totalRevenue = $totals['landshare_payments'];
        } elseif ($category === 'registration') {
            $totalCashin = $totals['registration_payments'];
            $totalRevenue = $totals['registration_payments'];
        } elseif ($category === 'service_fee') {
            $totalCashin = $totals['service_fee'];
            $totalRevenue = $totals['service_fee'];
        }  elseif ($category === 'booking_money') {
            $totalCashin = $totals['booking_money'];
            $totalRevenue = $totals['booking_money'];
        } elseif ($category === 'management_cashin') {
            $totalCashin = $totals['management_cashin'];
            $totalRevenue = $totals['management_cashin'];
        }

        return [
            'period' => 'Custom Range (Daily)',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'opening_balance' => $this->getOpeningBalance($startDate, $projectId, $category),
            'daily_data' => $dailyData,
            'summary' => [
                'total_booking_money' => $totals['booking_money'],
                'total_registration_payments' => $totals['registration_payments'],
                'total_emi_payments' => $totals['emi_payments'],
                'total_landshare_payments' => $totals['landshare_payments'],
                'total_service_fee' => $totals['service_fee'],
                'total_management_cashin' => $totals['management_cashin'],
                'total_discount' => $totals['discount'],
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue,
                'total_cash_out' => $totals['cash_out'],
                'net_balance' => $totalCashin - $totals['cash_out'],
                'final_balance' => $category === 'all' ? $runningBalance : $totalCashin
            ]
        ];
    }

    private function getDailyPaymentByTypeSingle($paymentType, $date, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(lp.amount), 0) as total_amount
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE DATE(lp.payment_date) = ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = ?
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $date, $paymentType, $projectId);
        } else {
            $stmt->bind_param("ss", $date, $paymentType);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_amount'] ?? 0);
    }


   
    private function getDailyServiceFeeSingle($date, $projectId = null)
    {
        if ($projectId) {
            $query = "
                SELECT COALESCE(SUM(es.service_fee), 0) as total
                FROM emi_schedules es
                LEFT JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE DATE(es.due_date) = ?
                AND es.status = 'paid'
                AND lb.project_id = ?
            ";
        } else {
            $query = "
                SELECT COALESCE(SUM(service_fee), 0) as total
                FROM emi_schedules
                WHERE DATE(due_date) = ?
                AND status = 'paid'
            ";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("si", $date, $projectId);
        } else {
            $stmt->bind_param("s", $date);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total'] ?? 0);
    }

    private function getDailyManagementCashinSingle($date)
    {
        $query = "
            SELECT COALESCE(SUM(amount), 0) as total
            FROM management_cashin
            WHERE DATE(transaction_date) = ?
            AND payment_status = 'paid'
        ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total'] ?? 0);
    }

    private function getDailyDiscountSingle($date, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(discount_amount), 0) as total_amount
            FROM lead_bookings
            WHERE DATE(booking_date) = ?
            AND booking_status = 'booked'
            AND landshare_status = 'active'
        ";

        if ($projectId) {
            $query .= " AND project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("si", $date, $projectId);
        } else {
            $stmt->bind_param("s", $date);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_amount'] ?? 0);
    }

    /**
     * Get custom monthly statement
     */
    /**
     * Get custom monthly statement with total_cashin support
     */
    private function getCustomMonthlyStatement($startDate, $endDate, $projectId = null, $category = 'all')
    {
        // Convert empty string to null
        if ($projectId === '') {
            $projectId = null;
        }

        $monthlyData = [];

        $start = strtotime(date('Y-m-01', strtotime($startDate)));
        $end = strtotime(date('Y-m-t', strtotime($endDate)));

        // Get opening balance before the period
        $runningBalance = $this->getOpeningBalance(date('Y-m-01', strtotime($startDate)), $projectId, $category);

        // Initialize totals
        $totals = [
            'landshare_payments' => 0,
            'registration_payments' => 0,
            'emi_payments' => 0,
            'booking_money' => 0,
            'service_fee' => 0,
            'management_cashin' => 0,
            'discount' => 0,
            'cash_out' => 0
        ];

        $current = $start;
        while ($current <= $end) {
            $monthStart = date('Y-m-01', $current);
            $monthEnd = date('Y-m-t', $current);

            // Get monthly totals
            $landsharePayments = $this->getMonthlyPaymentByType('land_share', $monthStart, $monthEnd, $projectId);
            $registrationPayments = $this->getMonthlyPaymentByType('registration', $monthStart, $monthEnd, $projectId);
            $emiPayments = $this->getMonthlyPaymentByType('emi', $monthStart, $monthEnd, $projectId);
            $bookingMoney = $this->getMonthlyPaymentByType('booking_money', $monthStart, $monthEnd, $projectId);
           
            $serviceFee = $this->getMonthlyServiceFee($monthStart, $monthEnd, $projectId);
            $managementCashin = $this->getMonthlyManagementCashin($monthStart, $monthEnd);
            $discount = $this->getMonthlyDiscount($monthStart, $monthEnd, $projectId);

            // Only get cashout for expense categories, not for revenue categories
            $cashOut = 0;
            if (in_array($category, ['all', 'cashout', 'utilities', 'other'])) {
                $cashOut = $this->getMonthlyCashOut($monthStart, $monthEnd, $category);
            }

            // Calculate cashin based on selected category
            $cashin = 0;
            if ($category === 'all' || $category === 'total_cashin') {
                // Total cashin includes all revenue sources minus discount
                $cashin = $landsharePayments + $registrationPayments + $bookingMoney + $emiPayments + $managementCashin;
            } elseif ($category === 'emi') {
                $cashin = $emiPayments;
            } elseif ($category === 'landshare') {
                $cashin = $landsharePayments;
            } elseif ($category === 'registration') {
                $cashin = $registrationPayments;
            } elseif ($category === 'service_fee') {
                $cashin = $serviceFee;
            } elseif ($category === 'booking_money') {
                $cashin = $bookingMoney;
            } elseif ($category === 'management_cashin') {
                $cashin = $managementCashin;
            }

            $netAmount = $cashin - $cashOut;

            // Only update running balance for 'all' category
            if ($category === 'all') {
                $runningBalance += $netAmount;
            }

            // Accumulate totals
            $totals['landshare_payments'] += $landsharePayments;
            $totals['registration_payments'] += $registrationPayments;
            $totals['emi_payments'] += $emiPayments;
            $totals['booking_money'] += $bookingMoney;
            $totals['service_fee'] += $serviceFee;
            $totals['management_cashin'] += $managementCashin;
            $totals['discount'] += $discount;
            $totals['cash_out'] += $cashOut;

            $monthlyData[] = [
                'month' => date('F Y', $current),
                'year' => date('Y', $current),
                'month_num' => date('m', $current),
                // Detailed breakdown
                'booking_money' => $bookingMoney,
                'registration_payments' => $registrationPayments,
                'emi_payments' => $emiPayments,
                'landshare_payments' => $landsharePayments,
                'service_fee' => $serviceFee,
                'management_cashin' => $managementCashin,
                'discount' => $discount,
                'total_cashin' => $cashin,
                'cash_out' => $cashOut,
                'net_amount' => $netAmount,
                'running_balance' => $category === 'all' ? $runningBalance : $cashin,

                'total_revenue' => $cashin
            ];

            $current = strtotime('+1 month', $current);
        }

        // Calculate final totals based on category
        $totalCashin = 0;
        $totalRevenue = 0;

        if ($category === 'all' || $category === 'total_cashin') {
            $totalCashin = $totals['landshare_payments'] + $totals['registration_payments'] +
                $totals['booking_money'] + $totals['emi_payments'] + $totals['management_cashin'];
            $totalRevenue = $totals['landshare_payments'] + $totals['booking_money'] + $totals['service_fee'];
        } elseif ($category === 'emi') {
            $totalCashin = $totals['emi_payments'];
            $totalRevenue = $totals['emi_payments'];
        } elseif ($category === 'landshare') {
            $totalCashin = $totals['landshare_payments'];
            $totalRevenue = $totals['landshare_payments'];
        } elseif ($category === 'registration') {
            $totalCashin = $totals['registration_payments'];
            $totalRevenue = $totals['registration_payments'];
        } elseif ($category === 'service_fee') {
            $totalCashin = $totals['service_fee'];
            $totalRevenue = $totals['service_fee'];
        }  elseif ($category === 'booking_money') {
            $totalCashin = $totals['booking_money'];
            $totalRevenue = $totals['booking_money'];
        } elseif ($category === 'management_cashin') {
            $totalCashin = $totals['management_cashin'];
            $totalRevenue = $totals['management_cashin'];
        }

        return [
            'period' => 'Custom Range (Monthly)',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'opening_balance' => $this->getOpeningBalance(date('Y-m-01', strtotime($startDate)), $projectId, $category),
            'monthly_data' => $monthlyData,
            'summary' => [
                'total_booking_money' => $totals['booking_money'],
                'total_registration_payments' => $totals['registration_payments'],
                'total_emi_payments' => $totals['emi_payments'],
                'total_landshare_payments' => $totals['landshare_payments'],
                'total_service_fee' => $totals['service_fee'],
                'total_management_cashin' => $totals['management_cashin'],
                'total_discount' => $totals['discount'],
                'total_cashin' => $totalCashin,
                'total_revenue' => $totalRevenue,
                'total_cash_out' => $totals['cash_out'],
                'net_balance' => $totalCashin - $totals['cash_out'],
                'final_balance' => $category === 'all' ? $runningBalance : $totalCashin,
                // Backward compatibility
                'total_landshare' => $totals['landshare_payments']
            ]
        ];
    }

    /**
     * Helper: Get opening balance before a specific date
     */
    private function getOpeningBalance($startDate, $projectId = null, $category = 'all')
    {
        // Get all payments before start date
        $paymentsQuery = "
            SELECT COALESCE(SUM(lp.amount), 0) as total
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE DATE(lp.payment_date) < ? 
            AND lp.payment_status = 'paid'
        ";



        // Get all service fee before start date from emi_schedules
        $serviceFeeQuery = "
            SELECT COALESCE(SUM(service_fee), 0) as total
            FROM emi_schedules
            WHERE DATE(due_date) < ? 
            AND status = 'paid'
        ";

        // Get all management cashin before start date
        $cashinQuery = "
            SELECT COALESCE(SUM(amount), 0) as total
            FROM management_cashin
            WHERE DATE(transaction_date) < ? 
            AND payment_status = 'paid'
        ";

        // Get all cash-out before start date
        $cashOutQuery = $this->getOpeningCashOutQuery($category, $startDate);

        // Add project filter if specified
        if ($projectId) {
            $paymentsQuery .= " AND lb.project_id = ?";

            // For service fee with project filter
            $serviceFeeQuery = "
                SELECT COALESCE(SUM(es.service_fee), 0) as total
                FROM emi_schedules es
                LEFT JOIN lead_bookings lb ON es.lead_booking_id = lb.id
                WHERE DATE(es.due_date) < ?
                AND es.status = 'paid'
                AND lb.project_id = ?
            ";
        }

        // Get total payments
        $totalPayments = 0;
        $stmt = $this->db->prepare($paymentsQuery);
        if ($projectId) {
            $stmt->bind_param("si", $startDate, $projectId);
        } else {
            $stmt->bind_param("s", $startDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $totalPayments = (float)$row['total'];
        }



        // Get service fees
        $totalServiceFee = 0;
        $stmt = $this->db->prepare($serviceFeeQuery);
        if ($projectId) {
            $stmt->bind_param("si", $startDate, $projectId);
        } else {
            $stmt->bind_param("s", $startDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $totalServiceFee = (float)$row['total'];
        }

        // Get management cashin
        $totalManagementCashin = 0;
        $stmt = $this->db->prepare($cashinQuery);
        $stmt->bind_param("s", $startDate);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $totalManagementCashin = (float)$row['total'];
        }

        // Get cash-out
        $totalCashOut = 0;
        $stmt = $this->db->prepare($cashOutQuery);

        if ($category === 'utilities') {
            $stmt->bind_param("s", $startDate);
        } else {
            $stmt->bind_param("ss", $startDate, $startDate);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $totalCashOut = (float)$row['total'];
        }

        // Calculate opening balance based on the cashin formula
        $landsharePayments = $this->getTotalPaymentByTypeBeforeDate('land_share', $startDate, $projectId);
        $registrationPayments = $this->getTotalPaymentByTypeBeforeDate('registration', $startDate, $projectId);
        $emiPayments = $this->getTotalPaymentByTypeBeforeDate('emi', $startDate, $projectId);
        $totalBookingMoney = $this->getTotalPaymentByTypeBeforeDate('booking_money', $startDate, $projectId);
        $totalDiscount = $this->getTotalDiscountBeforeDate($startDate, $projectId);

        $openingCashin = $landsharePayments + $registrationPayments + $totalBookingMoney + $emiPayments - $totalDiscount;

        // Opening balance = Cashin - Cash out
        $openingBalance = $openingCashin - $totalCashOut;

        return $openingBalance;
    }

    private function getTotalPaymentByTypeBeforeDate($paymentType, $date, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(lp.amount), 0) as total_amount
            FROM lead_payments lp
            INNER JOIN lead_bookings lb ON lp.booking_id = lb.id
            WHERE DATE(lp.payment_date) < ?
            AND lp.payment_status = 'paid'
            AND lp.payment_type = ?
        ";

        if ($projectId) {
            $query .= " AND lb.project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssi", $date, $paymentType, $projectId);
        } else {
            $stmt->bind_param("ss", $date, $paymentType);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_amount'] ?? 0);
    }

    private function getTotalDiscountBeforeDate($date, $projectId = null)
    {
        $query = "
            SELECT COALESCE(SUM(discount_amount), 0) as total_discount
            FROM lead_bookings
            WHERE DATE(booking_date) < ?
            AND booking_status = 'booked'
            AND landshare_status = 'active'
        ";

        if ($projectId) {
            $query .= " AND project_id = ?";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("si", $date, $projectId);
        } else {
            $stmt->bind_param("s", $date);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return (float)($row['total_discount'] ?? 0);
    }

    /**
     * Helper: Get opening cashout query based on category
     */
    // Update the getOpeningCashOutQuery method:
    private function getOpeningCashOutQuery($category, $startDate, $projectId = null)
    {
        if ($category === 'utilities') {
            $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

            $keywordConditions = [];
            foreach ($utilityKeywords as $keyword) {
                $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
            }
            $keywordCondition = implode(' OR ', $keywordConditions);

            $projectCondition = "";
            if ($projectId) {
                $projectCondition = " AND (cr.project_id = ? OR cp.project_id = ?)";
            }

            return "
            SELECT COALESCE(SUM(total_amount), 0) as total
            FROM (
                SELECT cp.amount as total_amount
                FROM cashout_payments cp
                LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
                WHERE DATE(cp.payment_date) < ?
                AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
                AND ($keywordCondition)
                $projectCondition
            ) combined
        ";
        }

        $projectCondition = "";
        if ($projectId) {
            $projectCondition = " AND (cr.project_id = ? OR cp.project_id = ?)";
        }

        return "
        SELECT COALESCE(SUM(total_amount), 0) as total
        FROM (
            -- Management cashout
            SELECT amount as total_amount
            FROM management_cashout
            WHERE DATE(transaction_date) < ? 
            AND payment_status = 'paid'
            
            UNION ALL
            
            -- Cashout request payments
            SELECT cp.amount as total_amount
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            WHERE DATE(cp.payment_date) < ?
            AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
            $projectCondition
        ) combined
    ";
    }

    /**
     * Helper: Get daily cash-out total
     */
    /**
     * Helper: Get daily cash-out total
     */
    private function getDailyCashOut($date, $category = 'all', $projectId = null)
    {
        if ($category === 'utilities') {
            return $this->getDailyUtilitiesCashOut($date, $projectId);
        }

        // Get category ID if a specific category is selected (for management_cashout)
        $categoryId = null;
        if ($category !== 'all' && $category !== 'cashout' && $category !== 'emi') {
            $categoryId = $this->getCategoryIdByName($category);
        }

        // Query for other categories
        $query = "
        SELECT COALESCE(SUM(total_amount), 0) as total
        FROM (
            -- Management cashout
            SELECT amount as total_amount
            FROM management_cashout
            WHERE DATE(transaction_date) = ? 
            AND payment_status = 'paid'
            " . ($categoryId ? "AND category_id = ?" : "") . "
            
            UNION ALL
            
            -- Cashout request payments (only for 'cashout' or 'all' categories)
            " . (($category === 'all' || $category === 'cashout') ? "
            SELECT cp.amount as total_amount
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            WHERE DATE(cp.payment_date) = ?
            AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
            " . ($projectId ? " AND (cr.project_id = ? OR cp.project_id = ?)" : "") . "
            " : "SELECT 0 as total_amount") . "
            
            UNION ALL
            
            -- Salary payments (payslips) - only for 'all' category
            " . ($category === 'all' ? "
            SELECT net_salary as total_amount
            FROM payslips
            WHERE DATE(updated_at) = ?
            AND status = 'paid'
            " : "SELECT 0 as total_amount") . "
        ) combined
    ";

        $stmt = $this->db->prepare($query);
        if (!$stmt) {
            throw new RuntimeException("SQL Prepare Error: " . $this->db->error);
        }

        // Bind parameters based on category
        $params = [];
        $types = "";

        if ($categoryId) {
            // With category ID (for management_cashout with specific category)
            $params[] = $date;
            $params[] = $categoryId;
            $types = "si";
        } else if ($category === 'all' && $projectId) {
            // All categories with project filter: date, date, projectId, projectId, date
            $params = [$date, $date, $projectId, $projectId, $date];
            $types = "ssiiss";
        } else if ($category === 'all') {
            // All categories: date, date, date
            $params = [$date, $date, $date];
            $types = "sss";
        } else if ($category === 'cashout' && $projectId) {
            // Cashout only with project filter: date, date, projectId, projectId
            $params = [$date, $date, $projectId, $projectId];
            $types = "ssii";
        } else if ($category === 'cashout') {
            // Cashout only: date, date
            $params = [$date, $date];
            $types = "ss";
        } else {
            // Other categories (emi, landshare, service_fee, etc.) - no cashout for these
            // Just management cashout with no category filter
            $params = [$date];
            $types = "s";
        }

        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return (float)($row['total'] ?? 0);
    }

    /**
     * Helper: Get daily utilities cashout from cashout_requests
     */
    private function getDailyUtilitiesCashOut($date, $projectId = null)
    {
        $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

        $keywordConditions = [];
        foreach ($utilityKeywords as $keyword) {
            $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
        }
        $keywordCondition = implode(' OR ', $keywordConditions);

        $query = "
        SELECT COALESCE(SUM(cp.amount), 0) as total
        FROM cashout_payments cp
        LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
        WHERE DATE(cp.payment_date) = ?
        AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
        AND ($keywordCondition)
    ";

        // Add project filter if specified
        if ($projectId) {
            $query .= " AND (cr.project_id = ? OR cp.project_id = ?)";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("sii", $date, $projectId, $projectId);
        } else {
            $stmt->bind_param("s", $date);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return (float)($row['total'] ?? 0);
    }

    /**
     * Helper: Get monthly cash-out total
     */
    /**
     * Helper: Get monthly cash-out total
     */
    private function getMonthlyCashOut($startDate, $endDate, $category = 'all', $projectId = null)
    {
        // Convert empty string to null
        if ($projectId === '') {
            $projectId = null;
        }

        if ($category === 'utilities') {
            return $this->getMonthlyUtilitiesCashOut($startDate, $endDate, $projectId);
        }

        // Get category ID if a specific category is selected (for management_cashout)
        $categoryId = null;
        if ($category !== 'all' && $category !== 'cashout' && $category !== 'emi') {
            $categoryId = $this->getCategoryIdByName($category);
        }

        // Query for other categories
        $query = "
        SELECT COALESCE(SUM(total_amount), 0) as total
        FROM (
            -- Management cashout
            SELECT amount as total_amount
            FROM management_cashout
            WHERE DATE(transaction_date) BETWEEN ? AND ? 
            AND payment_status = 'paid'
            " . ($categoryId ? "AND category_id = ?" : "") . "
            
            UNION ALL
            
            -- Cashout request payments (only for 'cashout' or 'all' categories)
            " . (($category === 'all' || $category === 'cashout') ? "
            SELECT cp.amount as total_amount
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            WHERE DATE(cp.payment_date) BETWEEN ? AND ?
            AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
            " . ($projectId ? " AND (cr.project_id = ? OR cp.project_id = ?)" : "") . "
            " : "SELECT 0 as total_amount") . "
            
            UNION ALL
            
            -- Salary payments (payslips) - only for 'all' category
            " . ($category === 'all' ? "
            SELECT net_salary as total_amount
            FROM payslips
            WHERE DATE(updated_at) BETWEEN ? AND ?
            AND status = 'paid'
            " : "SELECT 0 as total_amount") . "
        ) combined
    ";

        $stmt = $this->db->prepare($query);
        if (!$stmt) {
            throw new RuntimeException("SQL Prepare Error: " . $this->db->error);
        }

        // Bind parameters based on category
        $params = [];
        $types = "";

        if ($categoryId) {
            // With category ID: start, end, categoryId
            $params = [$startDate, $endDate, $categoryId];
            $types = "ssi";
        } else if ($category === 'all' && $projectId) {
            // All categories with project filter
            $params = [$startDate, $endDate, $startDate, $endDate, $projectId, $projectId, $startDate, $endDate];
            $types = "ssssiiii";
        } else if ($category === 'all') {
            // All categories: start, end, start, end, start, end
            $params = [$startDate, $endDate, $startDate, $endDate, $startDate, $endDate];
            $types = "ssssss";
        } else if ($category === 'cashout' && $projectId) {
            // Cashout only with project filter
            $params = [$startDate, $endDate, $startDate, $endDate, $projectId, $projectId];
            $types = "ssssii";
        } else if ($category === 'cashout') {
            // Cashout only: start, end, start, end
            $params = [$startDate, $endDate, $startDate, $endDate];
            $types = "ssss";
        } else {
            // Other categories (emi, landshare, service_fee, etc.) - just management cashout
            $params = [$startDate, $endDate];
            $types = "ss";
        }

        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return (float)($row['total'] ?? 0);
    }

    /**
     * Helper: Get monthly utilities cashout from cashout_requests
     */
    private function getMonthlyUtilitiesCashOut($startDate, $endDate, $projectId = null)
    {
        $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

        $keywordConditions = [];
        foreach ($utilityKeywords as $keyword) {
            $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
        }
        $keywordCondition = implode(' OR ', $keywordConditions);

        $query = "
        SELECT COALESCE(SUM(cp.amount), 0) as total
        FROM cashout_payments cp
        LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
        WHERE DATE(cp.payment_date) BETWEEN ? AND ?
        AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
        AND ($keywordCondition)
    ";

        // Add project filter if specified
        if ($projectId) {
            $query .= " AND (cr.project_id = ? OR cp.project_id = ?)";
        }

        $stmt = $this->db->prepare($query);
        if ($projectId) {
            $stmt->bind_param("ssii", $startDate, $endDate, $projectId, $projectId);
        } else {
            $stmt->bind_param("ss", $startDate, $endDate);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return (float)($row['total'] ?? 0);
    }

    /**
     * Get overall statistics with period filter
     */
    public function getOverallStatistics($periodType = 'all_time', $year = null, $month = null, $startDate = null, $endDate = null, $projectId = null, $category = 'all')
    {
        // Build date range based on period type
        if ($periodType === 'monthly' && $year && $month) {
            $monthPadded = sprintf("%02d", $month);
            $startDate = "$year-$monthPadded-01";
            $endDate = date('Y-m-t', strtotime($startDate));
        } elseif ($periodType === 'yearly' && $year) {
            $startDate = "$year-01-01";
            $endDate = "$year-12-31";
        } elseif ($periodType === 'custom' && $startDate && $endDate) {
            // Use provided dates
        } else {
            // Default to all time
            $startDate = null;
            $endDate = null;
        }

        // Calculate revenue for the period
        $revenueData = $this->calculateRevenue($startDate, $endDate, $projectId);

        // Get cash-out for the period
        $cashOutData = $this->getCashOutForPeriod($startDate, $endDate, $category, $projectId);
        $totalCashOut = $cashOutData['total'] ?? 0;

        return [
            'total_booking_money' => $revenueData['summary']['total_booking_money'],
            'total_landshare_payments' => $revenueData['summary']['total_landshare_payments'],
            'total_registration_payments' => $revenueData['summary']['total_registration_payments'],
            'total_emi_payments' => $revenueData['summary']['total_emi_payments'],
            'total_service_fee' => $revenueData['summary']['total_service_fee'],
            'total_discount' => $revenueData['summary']['total_discount_from_bookings'],
            'total_cashin' => $revenueData['summary']['total_cashin'],
            'total_revenue' => $revenueData['summary']['total_revenue'],
            'total_cash_out' => $totalCashOut,
            'net_balance' => $revenueData['summary']['total_cashin'] - $totalCashOut
        ];
    }

    private function getCashOutForPeriod($startDate, $endDate, $category = 'all', $projectId = null)
    {
        if ($category === 'utilities') {
            return $this->getUtilitiesCashOutForPeriod($startDate, $endDate, $projectId);
        }

        // Get category ID if a specific category is selected (for management_cashout)
        $categoryId = null;
        if ($category !== 'all' && $category !== 'cashout') {
            $categoryId = $this->getCategoryIdByName($category);
        }

        // Build date conditions
        $dateCondition = "";
        $params = [];
        $types = "";

        if ($startDate && $endDate) {
            $dateCondition = " AND DATE(transaction_date) BETWEEN ? AND ?";
            $params = [$startDate, $endDate];
            $types = "ss";
        }

        // Project condition for cashout requests
        $projectCondition = "";
        if ($projectId && ($category === 'all' || $category === 'cashout')) {
            $projectCondition = " AND (cr.project_id = ? OR cp.project_id = ?)";
        }

        // Query for other categories
        $query = "
        SELECT COALESCE(SUM(total_amount), 0) as total
        FROM (
            -- Management cashout
            SELECT amount as total_amount
            FROM management_cashout
            WHERE payment_status = 'paid'
            {$dateCondition}
            " . ($categoryId ? " AND category_id = ?" : "") . "
            
            UNION ALL
            
            -- Cashout request payments (only for 'cashout' or 'all' categories)
            " . (($category === 'all' || $category === 'cashout') ? "
            SELECT cp.amount as total_amount
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            WHERE cr.status IN ('approved', 'partially_paid', 'fully_paid')
            " . ($startDate && $endDate ? " AND DATE(cp.payment_date) BETWEEN ? AND ?" : "") . "
            {$projectCondition}
            " : "SELECT 0 as total_amount") . "
            
            UNION ALL
            
            -- Salary payments (payslips) - only for 'all' category
            " . ($category === 'all' ? "
            SELECT net_salary as total_amount
            FROM payslips
            WHERE status = 'paid'
            " . ($startDate && $endDate ? " AND DATE(updated_at) BETWEEN ? AND ?" : "") . "
            " : "SELECT 0 as total_amount") . "
        ) combined
    ";

        $stmt = $this->db->prepare($query);
        if (!$stmt) {
            throw new RuntimeException("SQL Prepare Error: " . $this->db->error);
        }

        // Build parameters array
        $bindParams = [];
        $bindTypes = "";

        if ($categoryId) {
            // With category ID
            if ($startDate && $endDate) {
                $bindParams = array_merge($bindParams, [$startDate, $endDate, $categoryId]);
                $bindTypes .= "ssi";
            } else {
                $bindParams = array_merge($bindParams, [$categoryId]);
                $bindTypes .= "i";
            }
        }

        if ($category === 'all' || $category === 'cashout') {
            if ($startDate && $endDate) {
                $bindParams = array_merge($bindParams, [$startDate, $endDate]);
                $bindTypes .= "ss";
            }
            if ($projectId) {
                $bindParams = array_merge($bindParams, [$projectId, $projectId]);
                $bindTypes .= "ii";
            }
        }

        if ($category === 'all') {
            if ($startDate && $endDate) {
                $bindParams = array_merge($bindParams, [$startDate, $endDate]);
                $bindTypes .= "ss";
            }
        }

        if (!empty($bindParams)) {
            $stmt->bind_param($bindTypes, ...$bindParams);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return [
            'total' => (float)($row['total'] ?? 0)
        ];
    }
    // Add this method to CentralStatement class:
    public function getProjectsWithCashout($category = 'cashout')
    {
        $query = "
        SELECT DISTINCT 
            p.id,
            p.name,
            p.location_id,
            p.community_id
        FROM projects p
        LEFT JOIN cashout_requests cr ON p.id = cr.project_id
        LEFT JOIN cashout_payments cp ON p.id = cp.project_id
        WHERE p.deleted_at IS NULL
        AND (cr.id IS NOT NULL OR cp.id IS NOT NULL)
        ORDER BY p.name
    ";

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        $projects = [];
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }

        return $projects;
    }

    // Also add this method to get all projects (for dropdown):
    public function getAllProjects()
    {
        $query = "
        SELECT id, name 
        FROM projects 
        WHERE deleted_at IS NULL 
        ORDER BY name
    ";

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        $projects = [];
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }

        return $projects;
    }
    private function getUtilitiesCashOutForPeriod($startDate, $endDate, $projectId = null)
    {
        $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

        $keywordConditions = [];
        foreach ($utilityKeywords as $keyword) {
            $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
        }
        $keywordCondition = implode(' OR ', $keywordConditions);

        $dateCondition = "";
        $params = [];

        if ($startDate && $endDate) {
            $dateCondition = " AND DATE(cp.payment_date) BETWEEN ? AND ?";
            $params = [$startDate, $endDate];
        }

        $projectCondition = "";
        if ($projectId) {
            $projectCondition = " AND (cr.project_id = ? OR cp.project_id = ?)";
            $params = array_merge($params, [$projectId, $projectId]);
        }

        $query = "
        SELECT COALESCE(SUM(cp.amount), 0) as total
        FROM cashout_payments cp
        LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
        WHERE cr.status IN ('approved', 'partially_paid', 'fully_paid')
        AND ($keywordCondition)
        {$dateCondition}
        {$projectCondition}
    ";

        $stmt = $this->db->prepare($query);
        if (!$stmt) {
            throw new RuntimeException("SQL Prepare Error: " . $this->db->error);
        }

        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            if ($projectId) {
                $types = substr_replace($types, 'i', -2, 2);
            }
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        return [
            'total' => (float)($row['total'] ?? 0)
        ];
    }

    /**
     * Helper: Get category ID by name
     */
    private function getCategoryIdByName($categoryName)
    {
        // Map category names to IDs based on your management_categories table
        $categoryMap = [
            'cashout' => 2,
            'landshare' => null,
            'service_fee' => null,
            'emi' => null,  // Add EMI category
            'registration' => null,
            'booking_money' => null,
            'management_cashin' => null,
            'utilities' => 1,
            'other' => null
        ];

        return $categoryMap[$categoryName] ?? null;
    }

    /**
     * Get detailed utilities transactions for view
     */
    public function getUtilitiesTransactions($startDate, $endDate)
    {
        $utilityKeywords = ['bill', 'bills', 'electricity', 'wifi', 'internet', 'water', 'gas', 'utility', 'utilities', 'power', 'light', 'electric'];

        $keywordConditions = [];
        foreach ($utilityKeywords as $keyword) {
            $keywordConditions[] = "LOWER(cr.purpose_paid_to) LIKE '%" . $this->db->real_escape_string(strtolower($keyword)) . "%'";
        }
        $keywordCondition = implode(' OR ', $keywordConditions);

        $query = "
            SELECT 
                cp.id,
                cp.cashout_request_id,
                cp.amount,
                cp.payment_date,
                cp.payment_method,
                cp.transaction_ref,
                cr.purpose_paid_to,
                cr.description,
                u.full_name as requester_name
            FROM cashout_payments cp
            LEFT JOIN cashout_requests cr ON cp.cashout_request_id = cr.id
            LEFT JOIN users u ON cr.requested_by = u.id
            WHERE DATE(cp.payment_date) BETWEEN ? AND ?
            AND cr.status IN ('approved', 'partially_paid', 'fully_paid')
            AND ($keywordCondition)
            ORDER BY cp.payment_date DESC
        ";

        $stmt = $this->db->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        $result = $stmt->get_result();

        $transactions = [];
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }

        return $transactions;
    }
}

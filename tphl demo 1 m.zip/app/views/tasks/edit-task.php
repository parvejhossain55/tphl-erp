  <?php
    $page_title = "Edit Task";
    $page = 'Task Edit';
    $show_breadcrumb = true;
    ?>


  <div class="row">
      <div class="card__wrapper">
          <form action="<?= $GLOBALS['base_url'] ?>/update-task/<?= $task['id'] ?>" method="POST">
              <div class="row">
                  <div class="col-xxl-12">
                      <div class="row gy-10">
                          <div class="col-xl-12">
                              <div class="card__wrapper">
                                  <div class="row gy-20">

                                      <!-- Task Title -->
                                      <div class="col-lg-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label for="title">Task Title<span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <input class="form-control" name="title" id="title" type="text"
                                                      value="<?= htmlspecialchars($task['title']) ?>">
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Assigned Employee -->
                                      <div class="col-lg-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label for="employee_id">Assigned Employee <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <select id="employee_id" name="employee_id" class="form-select">
                                                      <?php foreach ($employees as $employee): ?>
                                                          <option value="<?= $employee['id'] ?>"
                                                              <?= $employee['id'] == $task['employee_id'] ? 'selected' : '' ?>>
                                                              <?= $employee['full_name'] ?>
                                                          </option>
                                                      <?php endforeach; ?>
                                                  </select>
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Start Date -->
                                      <div class="col-md-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label>Start Date <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <input class="form-control" id="startingDate" type="text" readonly
                                                      name="start_date" value="<?= $task['start_date'] ?>">
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Deadline -->
                                      <div class="col-md-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label>Deadline <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <input class="form-control" id="humanFriendlyDates" type="text" readonly
                                                      name="deadline" value="<?= $task['deadline'] ?>">
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Priority -->
                                      <div class="col-lg-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label for="projectPriority">Priority <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <select id="projectPriority" name="priority" class="form-select">
                                                      <?php
                                                        $priorities = ['low', 'medium', 'high', 'urgent'];
                                                        foreach ($priorities as $p): ?>
                                                          <option value="<?= $p ?>" <?= $task['priority'] == $p ? 'selected' : '' ?>>
                                                              <?= ucfirst($p) ?>
                                                          </option>
                                                      <?php endforeach; ?>
                                                  </select>
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Status -->
                                      <div class="col-lg-6">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label for="projectStatus">Status <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <select id="projectStatus" name="status" class="form-select">
                                                      <?php
                                                        $statuses = ['pending', 'in_progress', 'complete', 'expired'];
                                                        foreach ($statuses as $s): ?>
                                                          <option value="<?= $s ?>" <?= $task['status'] == $s ? 'selected' : '' ?>>
                                                              <?= ucwords(str_replace('_', ' ', $s)) ?>
                                                          </option>
                                                      <?php endforeach; ?>
                                                  </select>
                                              </div>
                                          </div>
                                      </div>

                                      <!-- Description -->
                                      <div class="col-md-12">
                                          <div class="from__input-box">
                                              <div class="form__input-title">
                                                  <label>Task Description <span>*</span></label>
                                              </div>
                                              <div class="form__input">
                                                  <textarea id="tinymce_simple_textarea" name="description"><?= htmlspecialchars($task['description']) ?></textarea>
                                              </div>
                                          </div>
                                      </div>

                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>

                  <!-- Submit Button -->
                  <div class="submit__btn text-center mb-20">
                      <button class="btn btn-primary">Update Task</button>
                  </div>
              </div>
          </form>
      </div>
  </div>
<?php
// Disable layout for this page
$disable_layout = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Invoice - #<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; padding: 20px; }
            .invoice-container { box-shadow: none !important; margin: 0 !important; }
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }

        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 40px;
        }

        .invoice-header {
            border-bottom: 3px solid #2c3e50;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .company-info {
            display: flex;
            justify-content: space-between;
            align-items: start;
        }

        .company-logo h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .company-logo p {
            color: #7f8c8d;
            font-size: 14px;
            line-height: 1.6;
        }

        .invoice-title {
            text-align: right;
        }

        .invoice-title h2 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }

        .invoice-number {
            color: #7f8c8d;
            font-size: 14px;
        }

        .paid-stamp {
            display: inline-block;
            padding: 8px 20px;
            background: #27ae60;
            color: white;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .pending-stamp {
            display: inline-block;
            padding: 8px 20px;
            background: #f39c12;
            color: white;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .invoice-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .detail-section h3 {
            color: #2c3e50;
            font-size: 16px;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #ecf0f1;
        }

        .detail-label {
            color: #7f8c8d;
            font-weight: 500;
        }

        .detail-value {
            color: #2c3e50;
            font-weight: 600;
        }

        .payment-details {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .payment-details h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 18px;
        }

        .payment-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            font-size: 15px;
        }

        .payment-row.total {
            border-top: 2px solid #2c3e50;
            margin-top: 15px;
            padding-top: 15px;
            font-size: 20px;
            font-weight: bold;
            color: #2c3e50;
        }

        .payment-method-details {
            background: #e8f4f8;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-left: 4px solid #3498db;
        }

        .payment-method-details h4 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 16px;
        }

        .method-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .method-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
        }

        .description-box {
            background: #fff9e6;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-left: 4px solid #f39c12;
        }

        .description-box h4 {
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 16px;
        }

        .description-box p {
            color: #555;
            line-height: 1.6;
            white-space: pre-wrap;
        }

        .invoice-footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 2px solid #ecf0f1;
            text-align: center;
            color: #7f8c8d;
            font-size: 13px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            justify-content: flex-end;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: #3498db;
            color: white;
        }

        .btn-primary:hover {
            background: #2980b9;
        }

        .btn-secondary {
            background: #95a5a6;
            color: white;
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .btn-success {
            background: #27ae60;
            color: white;
        }

        .btn-success:hover {
            background: #229954;
        }

        .amount-highlight {
            font-size: 24px;
            font-weight: bold;
            color: #000;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            display: inline-block;
        }

        .badge-primary { background: #cce5ff; color: #004085; }

        .signature-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-top: 60px;
            padding-top: 20px;
        }

        .signature-box {
            text-align: center;
        }

        .signature-line {
            border-top: 2px solid #2c3e50;
            margin-top: 50px;
            padding-top: 10px;
            color: #7f8c8d;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="action-buttons no-print">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> Print Invoice
        </button>
        <button onclick="downloadPDF()" class="btn btn-success">
            <i class="fas fa-download"></i> Download PDF
        </button>
        <a href="<?= $GLOBALS['base_url'] ?>/management-cash-in" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <div class="invoice-container" id="invoice-content">
        <!-- Header -->
        <div class="invoice-header">
            <div class="company-info">
                <div class="company-logo">
                    <h1>The Premium Homes Ltd.</h1>
                    <p>Real Estate & Property Management</p>
                    <p>Land View Commercial Center, 9th Floor 28 Gulshan North C/A, <br> Gulshan Circle-2, Dhaka</p>
                    <p>Phone: +8801958253300</p>
                    <p>Email: info@thepremiumhomes.com</p>
                </div>
                <div class="invoice-title">
                    <h2>TRANSACTION RECEIPT</h2>
                    <p class="invoice-number">#MGT-REC-<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></p>
                    <p class="invoice-number">Date: <?= date('d M, Y', strtotime($transaction['transaction_date'] ?? 'now')) ?></p>
                    <?php if (($transaction['payment_status'] ?? 'paid') === 'paid'): ?>
                        <span class="paid-stamp">PAID</span>
                    <?php else: ?>
                        <span class="pending-stamp">PENDING</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Role & Transaction Details -->
        <div class="invoice-details">
            <div class="detail-section">
                <h3>Role Information</h3>
                <div class="detail-row">
                    <span class="detail-label">Role Name:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['role_name'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Person Name:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['person_name'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Transaction ID:</span>
                    <span class="detail-value">TXN-<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?></span>
                </div>
            </div>

            <div class="detail-section">
                <h3>Transaction Information</h3>
                <div class="detail-row">
                    <span class="detail-label">Source:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['source'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Created By:</span>
                    <span class="detail-value"><?= htmlspecialchars($transaction['created_by_name'] ?? 'N/A') ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Created At:</span>
                    <span class="detail-value"><?= date('d M, Y h:i A', strtotime($transaction['created_at'] ?? 'now')) ?></span>
                </div>
            </div>
        </div>

        <!-- Payment Details -->
        <div class="payment-details">
            <h3>Payment Details</h3>
            <div class="payment-row">
                <span>Transaction Date:</span>
                <span style="font-weight: 600;"><?= date('d M, Y', strtotime($transaction['transaction_date'] ?? 'now')) ?></span>
            </div>
            <div class="payment-row">
                <span>Payment Method:</span>
                <span style="font-weight: 600;"><?= strtoupper($transaction['payment_method'] ?? 'CASH') ?></span>
            </div>
            <?php if (!empty($transaction['transaction_ref'])): ?>
            <div class="payment-row">
                <span>Transaction Reference:</span>
                <span style="font-weight: 600;"><?= htmlspecialchars($transaction['transaction_ref']) ?></span>
            </div>
            <?php endif; ?>
            <div class="payment-row total">
                <span>Amount:</span>
                <span class="amount-highlight">৳<?= number_format($transaction['amount'] ?? 0, 2) ?></span>
            </div>
        </div>

        <!-- Payment Method Details - Only show if not cash -->
        <?php 
        $paymentMethod = $transaction['payment_method'] ?? 'cash';
        $showPaymentDetails = false;
        
        // Check if we need to show payment details based on payment method
        if ($paymentMethod !== 'cash') {
            $showPaymentDetails = true;
        }
        
        if ($showPaymentDetails && ($paymentMethod === 'bank' || $paymentMethod === 'cheque' || $paymentMethod === 'online')):
        ?>
        <div class="payment-method-details">
            <h4>Payment Method: <?= strtoupper($paymentMethod) ?></h4>
            <div class="method-info">
                <?php if ($paymentMethod === 'bank'): ?>
                    <?php if (!empty($transaction['bank_name'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Bank Name:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['bank_name']) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($transaction['bank_account_no'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Account Number:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['bank_account_no']) ?></span>
                    </div>
                    <?php endif; ?>
                <?php elseif ($paymentMethod === 'cheque'): ?>
                    <?php if (!empty($transaction['cheque_no'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Cheque Number:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['cheque_no']) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($transaction['bank_name'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Bank Name:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['bank_name']) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($transaction['bank_account_no'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Account Number:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['bank_account_no']) ?></span>
                    </div>
                    <?php endif; ?>
                <?php elseif ($paymentMethod === 'online'): ?>
                    <?php if (!empty($transaction['online_type'])): ?>
                    <div class="method-item">
                        <span class="detail-label">Online Service:</span>
                        <span class="detail-value"><?= htmlspecialchars($transaction['online_type']) ?></span>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Description -->
        <?php if (!empty($transaction['description'])): ?>
        <div class="description-box">
            <h4>Transaction Description</h4>
            <p><?= nl2br(htmlspecialchars($transaction['description'])) ?></p>
        </div>
        <?php endif; ?>

        <!-- Signature Section -->
        <div class="signature-section">
            <div class="signature-box">
                <div class="signature-line">Authorized Signature</div>
                <p style="font-size: 12px; color: #7f8c8d; margin-top: 5px;">Company Representative</p>
            </div>
            <div class="signature-box">
                <div class="signature-line">Receiver Signature</div>
                <p style="font-size: 12px; color: #7f8c8d; margin-top: 5px;"><?= htmlspecialchars($transaction['person_name'] ?? 'Recipient') ?></p>
            </div>
        </div>

        <!-- Footer -->
        <div class="invoice-footer">
            <p><strong>Thank you for your transaction!</strong></p>
            <p style="margin-top: 10px; font-size: 12px;">
                This receipt was generated on <?= date('d M, Y \a\t h:i A') ?>
            </p>
            <p style="margin-top: 5px; font-size: 11px;">
                For support: info@thepremiumhomes.com | +8801958253300
            </p>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script>
        function downloadPDF() {
            const element = document.getElementById('invoice-content');
            const opt = {
                filename: 'Management-Receipt-<?= str_pad($transaction['id'] ?? '0', 6, '0', STR_PAD_LEFT) ?>-<?= date('Ymd') ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, logging: false },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>
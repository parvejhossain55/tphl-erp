<div class="app__slide-wrapper p-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Sales Dashboard</h4>
            <strong class="text-muted">Performance</strong>
        </div>

    </div>
    <!-- KPI CARDS -->
    <div class="row g-20 mb-4">

        <div class="col-xxl-3 col-xl-6 col-md-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-regular fa-users"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Total Leads</h6>
                        <h3 class="card__title"><?= $totalLeadsCount ?? '' ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-3 col-xl-6 col-md-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-regular fa-user-plus"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">New Leads Today</h6>
                        <h3 class="card__title"><?= $todayLeads ?? '' ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-3 col-xl-6 col-md-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-regular fa-bell"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Follow-ups Due</h6>
                        <h3 class="card__title"><?= $followUpsDue ?? '' ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-3 col-xl-6 col-md-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-regular fa-circle-check"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Today Follow Up</h6>
                        <h3 class="card__title"><?= $totalTodayFollowUps ?></h3>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- REVENUE + CONVERSION -->
    <div class="row g-20 mb-4">
        <div class="col-xxl-3  col-md-3 col-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-regular fa-circle-check"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Total Flat Booking</h6>
                        <h3 class="card__title"><?= $onboardedClients ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <!-- TOTAL PROJECT -->
        <div class="col-xl-3 col-md-3 col-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-solid fa-building"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Total Project</h6>
                        <h3 class="card__title"><?= $totalProjects ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Warning: Array to string conversion in C:\xampp\htdocs\TPHL-ERP\app\views\sales-developments\sales-dashboard.php on line 67
Array -->
        <!-- BOOKING MONEY COLLECTED -->
        <div class="col-xl-3 col-md-3 col-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-solid fa-bangladeshi-taka-sign"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Booking Money Collected</h6>
                        <h3 class="card__title">
                            BDT <?= number_format($bookingCollected, 2) ?>
                        </h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- CONVERSION RATE -->
        <div class="col-xl-3 col-md-3 col-6">
            <div class="card__wrapper">
                <div class="d-flex align-items-center gap-sm">
                    <div class="card__icon">
                        <span><i class="fa-solid fa-chart-line"></i></span>
                    </div>
                    <div class="card__title-wrap">
                        <h6 class="card__sub-title mb-10">Conversion Rate</h6>
                        <h3 class="card__title">
                            <?= number_format($conversionRate, 2) ?>%
                        </h3>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Todays Follow up -->
    <div class="col-12 mt-3">
        <div class="card__wrapper">
            <div class="card__header d-flex justify-content-between align-items-center mb-3">
                <h5 class="card__title mb-0" id="transactionsTitle">
                    Today's Follow-ups
                </h5>

            </div>

            <div class="table__wrapper table-responsive">
                <table class="table mb-20">
                    <thead>
                        <tr class="table__title">
                            <th>S/L</th>
                            <th>Date</th>
                            <th>Lead Name</th>
                            <th>Project</th>
                            <th>Flat</th>
                            <th>Follow-up Employee</th>
                            <th>Last Follow Up Date</th>
                            <th>Today Follow-up</th>
                            <th>Last Decussion Note</th>
                            <th>Today Follow Up Action</th>
                        </tr>
                    </thead>
                    <tbody id="">
                        <?php if (!empty($todayFollowUpData)): ?>
                            <?php foreach ($todayFollowUpData as $key => $followUp): ?>
                                <tr>
                                    <td><?= $key + 1 ?></td>
                                    <td><?= date('d M, Y', strtotime($followUp['follow_up_date'])) ?></td>
                                    <td><?= htmlspecialchars($followUp['lead_name']) ?></td>
                                    <td><?= htmlspecialchars($followUp['project_name']) ?></td>
                                    <td><?= htmlspecialchars($followUp['flat_name']) ?></td>
                                    <td><?= htmlspecialchars($followUp['assigned_with_name']) ?></td>
                                    <td><?= date('d M, Y H:i', strtotime($followUp['follow_up_date'] . ' ' . $followUp['follow_up_time'])) ?></td>
                                    <td><?= date('d M, Y H:i', strtotime($followUp['next_follow_up_date'])) ?></td>
                                    <td><?= htmlspecialchars($followUp['discussion_note']) ?></td>
                                    <td><?= htmlspecialchars($followUp['next_action']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">f
                                    <div class="text-muted">
                                        No follow-ups found
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>